﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 기말_프로젝트_시작
{
    public partial class M_ModifyProduct : Form
    {
        DataTable productTable;
        DataTable modifyTable;
        public M_ModifyProduct()
        {
            InitializeComponent();
        }

        private void M_ModifyProduct_Load(object sender, EventArgs e)
        {
            // TODO: 이 코드는 데이터를 'dataSet1.PRODUCT' 테이블에 로드합니다. 필요 시 이 코드를 이동하거나 제거할 수 있습니다.
            this.pRODUCTTableAdapter.Fill(this.dataSet1.PRODUCT);
            // TODO: 이 코드는 데이터를 'dataSet1.P_MODIFY' 테이블에 로드합니다. 필요 시 이 코드를 이동하거나 제거할 수 있습니다.
            this.p_MODIFYTableAdapter.Fill(this.dataSet1.P_MODIFY);

            productTable = dataSet1.Tables["PRODUCT"];
            modifyTable = dataSet1.Tables["P_MODIFY"];
        }

        private void labelName_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e) // 상품 종류 검색
        {
            
            if (pRODUCTBindingSource1.Filter != null)
            {
                textBox1.Text = "";
                pRODUCTBindingSource1.RemoveFilter();
                button4.Text = "종류 검색";
            }
            else
            {
                pRODUCTBindingSource1.Filter = "P_KIND LIKE '%" + textBox1.Text + "%'";
                button4.Text = "필터 해제";
            }
            
        }

        private void button3_Click(object sender, EventArgs e) // 상품 이름 검색
        {
            if (pRODUCTBindingSource1.Filter != null)
            {
                textBox1.Text = "";
                pRODUCTBindingSource1.RemoveFilter();
                button3.Text = "이름 검색";
            }
            else
            {
                pRODUCTBindingSource1.Filter = "P_NAME LIKE '%" + textBox1.Text + "%'";
                button3.Text = "필터 해제";
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e) // 셀 클릭할 때
        {
            // textBox2.Text = dataGridView1.Rows[this.dataGridView1.CurrentCellAddress.Y].Cells[0].Value.ToString();
            
            if (e.RowIndex >= 0)
            {
                textBox2.Text = dataGridView1.Rows[e.RowIndex].Cells["P_KIND"].Value.ToString();
                textBox3.Text = dataGridView1.Rows[e.RowIndex].Cells["P_NO"].Value.ToString();
                textBox4.Text = dataGridView1.Rows[e.RowIndex].Cells["P_PRICE"].Value.ToString();
            }
            
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e) // 상품 가격 검색
        {
            
            if(textBox2.Text == "" && textBox3.Text == "") // P_KIND
            {
                MessageBox.Show("상품 종류를 입력해주세요");
            }
            else if (textBox2.Text != "" && textBox3.Text == "") // P_NO
            {
                MessageBox.Show("상품 번호를 입력해주세요");
            }

            if(textBox12.Text == "")
            {
                MessageBox.Show("상품 이름을 입력해주세요");
            }

            // 
            
            foreach (DataRow mydataRow in productTable.Rows) // P_PRICE 찾기
            {
                if (mydataRow["P_KIND"].ToString() == textBox2.Text && mydataRow["P_NO"].ToString() == textBox3.Text)
                {
                    textBox4.Text = mydataRow["P_PRICE"].ToString();
                    break;
                }
                else
                {
                    textBox4.Text = "";
                }
            }
        }

        private void button2_Click(object sender, EventArgs e) // 가격 변경 확정
        {
            DataRow[] productRows = dataSet1.Tables["PRODUCT"].Select($"P_NO = '{textBox3.Text}'");
            if (productRows.Length > 0)
            {
                DataRow productRow = productRows[0];
                string oldPrice = productRow["P_PRICE"].ToString(); // 이전 가격 생성
                string newPrice = textBox5.Text;

                // modifyNO 찾기
                var modifyNoRows = dataSet1.Tables["P_MODIFY"].AsEnumerable();
                int maxModifyNo = modifyNoRows.Any() ? modifyNoRows.Max(r => int.Parse(r["MODIFY_NO"].ToString())) : 0; // MAX 값 찾기
                string newModifyNo = (maxModifyNo + 1).ToString(); // Max + 1

                DataRow modifyRow = dataSet1.Tables["P_MODIFY"].NewRow();
                modifyRow["MODIFY_NO"] = newModifyNo; // 수정 식별 번호
                modifyRow["P_KIND"] = textBox2.Text; // 상품 종류
                modifyRow["P_NO"] = textBox3.Text; // 상품 번호
                modifyRow["PRE_PRICE"] = oldPrice; // 이전 가격
                modifyRow["NEXT_PRICE"] = newPrice; // 이후 가격
                modifyRow["P_NAME"] = textBox12.Text;
                // modifyRow["P_REVIEW"] = 0; // 리뷰 개수

                if (textBox5.Text == "")
                {
                    MessageBox.Show("원하는 가격을 입력해주세요");
                }

                modifyRow["MODIFY_DATE"] = DateTime.Now; // 날짜
                dataSet1.Tables["P_MODIFY"].Rows.Add(modifyRow); // MODIFY 테이블 추가 완료

                // PRODUCT 가격 업데이트
                productRow["P_PRICE"] = newPrice;
                pRODUCTTableAdapter.Update(this.dataSet1.PRODUCT); // 업데이트
                p_MODIFYTableAdapter.Update(this.dataSet1.P_MODIFY); // 업데이트

                textBox2.Text = "";
                textBox3.Text = "";
                textBox4.Text = "";
                textBox5.Text = "";

                MessageBox.Show("가격 변경이 적용되었습니다.");
            }
        }

        private void button1_Click(object sender, EventArgs e) // 업데이트 버튼
        {
            try
            {
                this.pRODUCTBindingSource1.EndEdit();
                int ret = this.pRODUCTTableAdapter.Update(this.dataSet1.PRODUCT);
                if (ret > 0)
                    MessageBox.Show("업데이트 완료!");
            }
            catch
            {
                MessageBox.Show("업데이트가 실패했습니다.");
            }
        }
    }
}
