﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 기말_프로젝트_시작
{
    public partial class SellerForm : Form
    {
        string USER;
        public SellerForm(string C_NAME)
        {
            InitializeComponent();
            USER = C_NAME;
        }

        private void SellerForm_Load(object sender, EventArgs e)
        {

        }

        public void loadform(object Form) // 로딩
        {
            if (this.panelMain.Controls.Count > 0)
            {
                this.panelMain.Controls.RemoveAt(0);
            }
            Form f = Form as Form;
            f.TopLevel = false;
            f.Dock = DockStyle.Fill;
            this.panelMain.Controls.Add(f);
            this.panelMain.Tag = f;
            f.Show();

            // loadform(new S_SellingProduct(USER)); // 판매중인 상품 보여주기
        }

        private void button9_Click(object sender, EventArgs e) // 닫기 버튼
        {
            Application.Exit(); // 모든 화면 닫기
        }

        private void button8_Click(object sender, EventArgs e) // 판매중인 상품
        {
            loadform(new S_SellingProduct(USER));
        }

        private void button6_Click(object sender, EventArgs e) // 구매 요청 확인
        {
            loadform(new S_BuyingRequest(USER));
        }

        private void button3_Click(object sender, EventArgs e) // 환불 요청 확인
        {
            loadform(new S_RefundRequest(USER));
        }

        private void button7_Click(object sender, EventArgs e) // 후기 보기
        {
            loadform(new S_Review(USER));
        }
    }
}
