﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 기말_프로젝트_시작
{
    public partial class C_LeaveUser : Form
    {
        DataTable usertable;
        string USER;
        public C_LeaveUser(String C_NO)
        {
            InitializeComponent();
            USER = C_NO;
        }

        private void C_LeaveUser_Load(object sender, EventArgs e)
        {
            customerTableAdapter1.Fill(this.dataSet1.CUSTOMER); // CUSTOMER 데이터 채우기
            buyingTableAdapter1.Fill(this.dataSet1.BUYING);
            cartTableAdapter1.Fill(this.dataSet1.CART);
            productTableAdapter1.Fill(this.dataSet1.PRODUCT);
            refundTableAdapter1.Fill(this.dataSet1.REFUND);
            reviewTableAdapter1.Fill(this.dataSet1.REVIEW);

            textBox7.Text = USER;
            listBox1.Items.Clear();

            usertable = dataSet1.Tables["CUSTOMER"];
            // cartTable = dataSet1.Tables["CART"];
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e) // 동의서 checkbox1
        {

        }

        private void button5_Click(object sender, EventArgs e) // 회원 탈퇴하기 버튼
        {
            // checkbox1 = true?
            if (checkBox1.Checked == false) // 동의서
            {
                MessageBox.Show("동의서에 체크해주세요");
                return;
            }

            try
            {
                // CUSTOMER 데이터 저장
                List<DataRow> rowsToDelete = new List<DataRow>(); // 삭제할 고객의 ROW 넣기

                // CART 검사
                foreach (DataRow mydataRow2 in dataSet1.Tables["CUSTOMER"].Rows)
                {
                    if (mydataRow2["C_NO"].ToString() == USER && mydataRow2["C_PASSWORD"].ToString() == textBox1.Text)
                    {
                        // 삭제할 행 리스트에 추가합니다.
                        rowsToDelete.Add(mydataRow2);
                    }
                }

                // BUYING 데이터 삭제
                foreach (DataRow row in rowsToDelete)
                {
                    // 각 고객 번호에 대해 BUYING 테이블에서 삭제
                    string customerNumber = row["C_NO"].ToString();
                    // BUYING TableAdapter와 Delete 메서드 사용
                    buyingTableAdapter1.DeleteBuying(customerNumber);
                }

                // CART 데이터 삭제
                foreach (DataRow row in rowsToDelete)
                {
                    string customerNumber = row["C_NO"].ToString();
                    cartTableAdapter1.DeleteCart(customerNumber);
                }

                // REVIEW 데이터 삭제
                foreach (DataRow row in rowsToDelete)
                {
                    string customerNumber = row["C_NO"].ToString();
                    reviewTableAdapter1.DeleteReview(customerNumber);
                }

                // REFUND 데이터 삭제
                foreach (DataRow row in rowsToDelete)
                {
                    string customerNumber = row["C_NO"].ToString();
                    refundTableAdapter1.DeleteRefund(customerNumber);
                }

                // CUTOMER 데이터 삭제
                foreach (DataRow row in rowsToDelete)
                {
                    row.Delete(); // DataRow의 Delete 메서드를 호출하여 표시합니다.
                    // DELETE FROM BUYING WHERE C_NO = :customerNumber;
                    // 삭제할 쿼리 : BUYING, CART, PRODUCT, REFUND, REVIEW -> CUSTOMER
                }

                // CUSTOMER 데이터 업데이트
                customerTableAdapter1.Update(this.dataSet1.CUSTOMER);
                MessageBox.Show("고객님의 정보가 완전히 삭제되었습니다.");

                Application.Exit(); // 모든 화면 닫기
            }
            catch (Exception ex)
            {
                MessageBox.Show("업데이트 중 오류가 발생했습니다: " + ex.Message);
            }
        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {

        }

        
    }
}
