﻿
namespace 기말_프로젝트_시작
{
    partial class S_SellingProduct
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.pRODUCTBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataSet1 = new 기말_프로젝트_시작.DataSet1();
            this.pRODUCTTableAdapter = new 기말_프로젝트_시작.DataSet1TableAdapters.PRODUCTTableAdapter();
            this.labelName = new System.Windows.Forms.Label();
            this.cNODataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pKINDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pNODataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pNAMEDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pPRICEDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pCOUNTDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pSELLDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pSOLDOUTDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.pDATEDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pREFUNDCNTDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pRODUCTBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.AntiqueWhite;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.cNODataGridViewTextBoxColumn,
            this.pKINDDataGridViewTextBoxColumn,
            this.pNODataGridViewTextBoxColumn,
            this.pNAMEDataGridViewTextBoxColumn,
            this.pPRICEDataGridViewTextBoxColumn,
            this.pCOUNTDataGridViewTextBoxColumn,
            this.pSELLDataGridViewTextBoxColumn,
            this.pSOLDOUTDataGridViewTextBoxColumn,
            this.pDATEDataGridViewTextBoxColumn,
            this.pREFUNDCNTDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.pRODUCTBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(0, 40);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 23;
            this.dataGridView1.Size = new System.Drawing.Size(800, 430);
            this.dataGridView1.TabIndex = 8;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // pRODUCTBindingSource
            // 
            this.pRODUCTBindingSource.DataMember = "PRODUCT";
            this.pRODUCTBindingSource.DataSource = this.dataSet1;
            // 
            // dataSet1
            // 
            this.dataSet1.DataSetName = "DataSet1";
            this.dataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // pRODUCTTableAdapter
            // 
            this.pRODUCTTableAdapter.ClearBeforeFill = true;
            // 
            // labelName
            // 
            this.labelName.AutoSize = true;
            this.labelName.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.labelName.ForeColor = System.Drawing.Color.DarkSlateBlue;
            this.labelName.Location = new System.Drawing.Point(350, 10);
            this.labelName.Name = "labelName";
            this.labelName.Size = new System.Drawing.Size(118, 21);
            this.labelName.TabIndex = 9;
            this.labelName.Text = "매장 재고 관리";
            // 
            // cNODataGridViewTextBoxColumn
            // 
            this.cNODataGridViewTextBoxColumn.DataPropertyName = "C_NO";
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.AntiqueWhite;
            this.cNODataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle2;
            this.cNODataGridViewTextBoxColumn.HeaderText = "판매자";
            this.cNODataGridViewTextBoxColumn.Name = "cNODataGridViewTextBoxColumn";
            // 
            // pKINDDataGridViewTextBoxColumn
            // 
            this.pKINDDataGridViewTextBoxColumn.DataPropertyName = "P_KIND";
            this.pKINDDataGridViewTextBoxColumn.HeaderText = "상품 종류";
            this.pKINDDataGridViewTextBoxColumn.Name = "pKINDDataGridViewTextBoxColumn";
            // 
            // pNODataGridViewTextBoxColumn
            // 
            this.pNODataGridViewTextBoxColumn.DataPropertyName = "P_NO";
            this.pNODataGridViewTextBoxColumn.HeaderText = "상품 번호";
            this.pNODataGridViewTextBoxColumn.Name = "pNODataGridViewTextBoxColumn";
            // 
            // pNAMEDataGridViewTextBoxColumn
            // 
            this.pNAMEDataGridViewTextBoxColumn.DataPropertyName = "P_NAME";
            this.pNAMEDataGridViewTextBoxColumn.HeaderText = "상품 이름";
            this.pNAMEDataGridViewTextBoxColumn.Name = "pNAMEDataGridViewTextBoxColumn";
            // 
            // pPRICEDataGridViewTextBoxColumn
            // 
            this.pPRICEDataGridViewTextBoxColumn.DataPropertyName = "P_PRICE";
            this.pPRICEDataGridViewTextBoxColumn.HeaderText = "가격";
            this.pPRICEDataGridViewTextBoxColumn.Name = "pPRICEDataGridViewTextBoxColumn";
            // 
            // pCOUNTDataGridViewTextBoxColumn
            // 
            this.pCOUNTDataGridViewTextBoxColumn.DataPropertyName = "P_COUNT";
            this.pCOUNTDataGridViewTextBoxColumn.HeaderText = "입고 개수";
            this.pCOUNTDataGridViewTextBoxColumn.Name = "pCOUNTDataGridViewTextBoxColumn";
            // 
            // pSELLDataGridViewTextBoxColumn
            // 
            this.pSELLDataGridViewTextBoxColumn.DataPropertyName = "P_SELL";
            this.pSELLDataGridViewTextBoxColumn.HeaderText = "판매 개수";
            this.pSELLDataGridViewTextBoxColumn.Name = "pSELLDataGridViewTextBoxColumn";
            // 
            // pSOLDOUTDataGridViewTextBoxColumn
            // 
            this.pSOLDOUTDataGridViewTextBoxColumn.DataPropertyName = "P_SOLDOUT";
            this.pSOLDOUTDataGridViewTextBoxColumn.FalseValue = "0";
            this.pSOLDOUTDataGridViewTextBoxColumn.HeaderText = "판매 가능";
            this.pSOLDOUTDataGridViewTextBoxColumn.Name = "pSOLDOUTDataGridViewTextBoxColumn";
            this.pSOLDOUTDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.pSOLDOUTDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.pSOLDOUTDataGridViewTextBoxColumn.TrueValue = "1";
            // 
            // pDATEDataGridViewTextBoxColumn
            // 
            this.pDATEDataGridViewTextBoxColumn.DataPropertyName = "P_DATE";
            this.pDATEDataGridViewTextBoxColumn.HeaderText = "입고일";
            this.pDATEDataGridViewTextBoxColumn.Name = "pDATEDataGridViewTextBoxColumn";
            // 
            // pREFUNDCNTDataGridViewTextBoxColumn
            // 
            this.pREFUNDCNTDataGridViewTextBoxColumn.DataPropertyName = "P_REFUNDCNT";
            this.pREFUNDCNTDataGridViewTextBoxColumn.HeaderText = "환불 횟수";
            this.pREFUNDCNTDataGridViewTextBoxColumn.Name = "pREFUNDCNTDataGridViewTextBoxColumn";
            // 
            // S_SellingProduct
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(800, 470);
            this.Controls.Add(this.labelName);
            this.Controls.Add(this.dataGridView1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "S_SellingProduct";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "S_SellingProduct";
            this.Load += new System.EventHandler(this.S_SellingProduct_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pRODUCTBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private DataSet1 dataSet1;
        private System.Windows.Forms.BindingSource pRODUCTBindingSource;
        private DataSet1TableAdapters.PRODUCTTableAdapter pRODUCTTableAdapter;
        private System.Windows.Forms.Label labelName;
        private System.Windows.Forms.DataGridViewTextBoxColumn cNODataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pKINDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pNODataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pNAMEDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pPRICEDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pCOUNTDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pSELLDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewCheckBoxColumn pSOLDOUTDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pDATEDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pREFUNDCNTDataGridViewTextBoxColumn;
    }
}