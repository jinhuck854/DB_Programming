﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 기말_프로젝트_시작
{
    public partial class ManagerForm : Form
    {
        public ManagerForm()
        {
            InitializeComponent();
        }

        public void loadform(object Form) // 로딩
        {
            if(this.panelMain.Controls.Count > 0)
            {
                this.panelMain.Controls.RemoveAt(0);
            }
            Form f = Form as Form;
            f.TopLevel = false;
            f.Dock = DockStyle.Fill;
            this.panelMain.Controls.Add(f);
            this.panelMain.Tag = f;
            f.Show();
            
        }

        private void button1_Click(object sender, EventArgs e) // 매장 재고 관리 : 판매가능, 환불된 것 등
        {
            loadform(new M_CheckProduct());
            // 매장_재고_링크ㅡhttps://icons8.kr/icon/22158/%EC%83%9D%EC%84%B1%EB%AC%BC
            /*
             컴퓨터_링크ㅡhttps://icons8.kr/icon/16982/%EC%9B%8C%ED%81%AC-%EC%8A%A4%ED%85%8C%EC%9D%B4%EC%85%98 
            */
        }

        private void button6_Click(object sender, EventArgs e) // 신규 상품 등록 : 신규 상품의 종류와 식별 번호, 이름, 가격 등 입력 -> 공지까지
        {
            // 신규 상품 등록 링크ㅡhttps://icons8.kr/icon/61006/%EC%83%88%EB%A1%9C%EC%9A%B4
            loadform(new M_NewProduct());
        }

        private void button7_Click(object sender, EventArgs e) // 기존 상품 수정 : 가격 변경 + 가격 변경 내역
        {
            // 기존 상품 등록 링크ㅡhttps://icons8.kr/icon/1GJO60PVY2yg/%EB%8D%B0%EC%9D%B4%ED%84%B0%EB%B2%A0%EC%9D%B4%EC%8A%A4-%EB%B0%B1%EC%97%85
            loadform(new M_ModifyProduct());
        }

        private void button8_Click(object sender, EventArgs e) // 인기 상품 및 환불 : 환불이 많은 상품 + 가장 잘 팔리는 상품
        {
            // 신규 종류 등록 링크ㅡhttps://icons8.kr/icon/84904/%EC%83%88%EB%A1%9C%EC%9A%B4
            loadform(new M_Refund());
        }

        private void button2_Click(object sender, EventArgs e) // 상품 구매 내역 : 회원별 구매 현황 - 구매 액수, 구매 횟수
        {
            // 상품 구매 내역 링크ㅡhttps://icons8.kr/icon/59857/%EA%B5%AC%EB%A7%A4-%EC%A3%BC%EB%AC%B8
            loadform(new M_ProductDetail());
        }

        
        private void button5_Click(object sender, EventArgs e) // 상품 판매액 통계 : 상품 종류별, 일별, 주별, 요일별 판매량 차트
        {
            // 상품 판매액 현황 링크ㅡhttps://icons8.kr/icon/60004/%ED%86%B5%EA%B3%84
            loadform(new M_ProductStatistics());
        }

        private void button4_Click(object sender, EventArgs e) // 고객 관리
        {
            // 고객 관리 링크ㅡhttps://icons8.kr/icon/86320/%EC%82%AC%EB%9E%8C-%EB%82%A8%EC%9E%90
            loadform(new M_UserManage());
        }

        private void button3_Click(object sender, EventArgs e) // 로그아웃
        {
            MessageBox.Show("로그아웃 되었습니다.");
            Application.Exit(); // 모든 화면 닫기
            // 상품 판매액 현황 링크ㅡhttps://icons8.kr/icon/oT2F0M3rSxHV/%ED%8C%90%EB%A7%A4-%EA%B0%80%EA%B2%A9%ED%91%9C
            // loadform(new M_ProductSales());
        }

        private void pictureBox1_Click(object sender, EventArgs e) // 메인 화면 그림
        {
            // 메인 하면 그림 링크ㅡhttps://icons8.kr/icon/nahBAh-W3Xhc/%EC%9B%8C%ED%81%AC-%EC%8A%A4%ED%85%8C%EC%9D%B4%EC%85%98
        }

        private void button9_Click(object sender, EventArgs e) // 닫기 버튼
        {
            Application.Exit(); // 모든 화면 닫기
        }

        private void panelHeader_Paint(object sender, PaintEventArgs e)
        {

        }

        private void ManagerForm_Load(object sender, EventArgs e)
        {

        }

        
    }
}
