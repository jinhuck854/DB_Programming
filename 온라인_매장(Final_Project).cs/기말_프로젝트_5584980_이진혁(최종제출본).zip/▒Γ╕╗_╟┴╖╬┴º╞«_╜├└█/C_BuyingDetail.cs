﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 기말_프로젝트_시작
{
    public partial class C_BuyingDetail : Form
    {
        string USER;
        int REFUND_NUM = 0;
        public C_BuyingDetail(string C_NAME)
        {
            InitializeComponent();
            USER = C_NAME;
        }

        private void C_BuyingDetail_Load(object sender, EventArgs e)
        {
            // TODO: 이 코드는 데이터를 'dataSet11.BUYING' 테이블에 로드합니다. 필요 시 이 코드를 이동하거나 제거할 수 있습니다.
            this.bUYINGTableAdapter.Fill(this.dataSet1.BUYING); // 환불하기 BUYING
            // TODO: 이 코드는 데이터를 'dataSet1.BUYING' 테이블에 로드합니다. 필요 시 이 코드를 이동하거나 제거할 수 있습니다.
            this.bUYINGTableAdapter.Fill(this.dataSet1.BUYING); // 전체 구매 내역 BUYING
            // productTableAdapter1.Fill(this.dataSet1.PRODUCT);
            refundTableAdapter1.Fill(this.dataSet1.REFUND); // REFUND
            productTableAdapter1.Fill(this.dataSet1.PRODUCT); // PRODUCT
            cartTableAdapter1.Fill(this.dataSet1.CART); // CART

            bUYINGBindingSource1.Filter = "C_NO = '" + USER.Replace("'", "''") + "'";
            bUYINGBindingSource2.Filter = "C_NO = '" + USER.Replace("'", "''") + "' AND B_OK <> 'NOT'";

            listBox1.Items.Clear();
        }

        private void button2_Click(object sender, EventArgs e) // 환불 요청하기
        {
            // 1. 식별 번호
            if(textBox1.Text == "")
            {
                MessageBox.Show("식별 번호를 입력해주세요.");
                return;
            }

            // 2. 환불 사유
            if (richTextBox1.Text == "")
            {
                MessageBox.Show("식별 번호를 입력해주세요.");
                return;
            }

            // 3. 동의서
            if (checkBox1.Checked == false) // 동의서
            {
                MessageBox.Show("동의서에 체크해주세요");
                return;
            }

            // BUYING(B_OK == OK) REFUND 테이블로 옮김
            try
            {
                foreach (DataRow mydataRow in dataSet1.Tables["BUYING"].Rows)
                {
                    // 환불 조건 : 찾는 물건 + 사용자 본인 + 구매한 제품(B_OK = OK)
                    if (textBox1.Text == mydataRow["CART_NO"].ToString() && mydataRow["C_NO"].ToString() == USER && mydataRow["B_OK"].ToString() == "OK")
                    {
                        // REFUND : 새로운 REFUND 생성 : REFUND_NO == MAX값
                        DataRow myNewDataRow = dataSet1.Tables["REFUND"].NewRow(); // 임시 Buying 테이블 생성
                        var modifyNoRows = dataSet1.Tables["REFUND"].AsEnumerable();
                        int maxModifyNo = modifyNoRows.Any() ? modifyNoRows.Max(r => int.Parse(r["REFUND_NO"].ToString())) : 0;
                        string newModifyNo = (maxModifyNo + 1).ToString();
                        REFUND_NUM = Convert.ToInt32(newModifyNo);

                        // REFUND : 데이터 입력
                        myNewDataRow["REFUND_NO"] = newModifyNo; // REFUND 식별 번호
                        myNewDataRow["C_NO"] = USER; // 사용자 이름
                        myNewDataRow["P_KIND"] = mydataRow["P_KIND"]; // 상품 종류
                        myNewDataRow["P_NO"] = mydataRow["P_NO"]; // 상품 번호
                        myNewDataRow["P_NAME"] = mydataRow["P_NAME"]; // 상품 번호
                        myNewDataRow["P_SELL"] = mydataRow["B_COUNT"]; // 상품 번호
                        myNewDataRow["S_NO"] = mydataRow["S_NO"]; // 판매자
                        myNewDataRow["P_NAME"] = mydataRow["P_NAME"]; // 판매자
                        myNewDataRow["REFUND_DATE"] = DateTime.Now; // 환불 날짜
                        myNewDataRow["REASON"] = richTextBox1.Text; // 환불 이유
                        myNewDataRow["IS_OK"] = "0";

                        dataSet1.Tables["REFUND"].Rows.Add(myNewDataRow); // REFUND에 환불 할 데이터 추가
                    }
                }
                refundTableAdapter1.Update(dataSet1.REFUND); // REFUND 업데이트 : 데이터 업데이트


                // BUYING의 B_OK = "환불 요청 완료" 로 바꿔야함 // 환불 된 것은 "환불 완료"
                foreach (DataRow mydataRow in dataSet1.Tables["BUYING"].Rows) // CART 테이블 열 찾기
                {
                    if (textBox1.Text == mydataRow["CART_NO"].ToString() && mydataRow["C_NO"].ToString() == USER && mydataRow["B_OK"].ToString() == "OK") // 식별 번호, 유저이름, OK인 상품을 "환불 요청 완료"로 바꾸기
                    {
                        mydataRow["B_OK"] = "환불 요청 완료"; // 환불 요청 완료로 변경
                    }
                }
                bUYINGTableAdapter.Update(dataSet1.BUYING);

                // PRODUCT P_REFUNDCNT + 1
                textBox1.Text = "";
                richTextBox1.Text = "";
                checkBox1.Checked = false;

                MessageBox.Show("환불 번호 " + REFUND_NUM +", 환불 요청 완료!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("업데이트 중 오류가 발생했습니다: " + ex.Message);
            }
        }
    }
}
