﻿using System.Windows.Forms;

public class CustomDatagridview : DataGridView
{
    private System.Windows.Forms.DataGridViewTextBoxColumn pNODataGridViewTextBoxColumn;
    private System.Windows.Forms.DataGridViewComboBoxColumn pKINDDataGridViewTextBoxColumn;
    private System.Windows.Forms.DataGridViewTextBoxColumn pNAMEDataGridViewTextBoxColumn;
    private System.Windows.Forms.DataGridViewTextBoxColumn pPRICEDataGridViewTextBoxColumn;
    private System.Windows.Forms.DataGridViewTextBoxColumn pCOUNTDataGridViewTextBoxColumn;
    private System.Windows.Forms.DataGridViewTextBoxColumn pDATEDataGridViewTextBoxColumn;
    private System.Windows.Forms.DataGridViewTextBoxColumn pREFUNDCNTDataGridViewTextBoxColumn;
    private System.Windows.Forms.DataGridViewCheckBoxColumn pSOLDOUTDataGridViewTextBoxColumn;
    private System.Windows.Forms.DataGridViewTextBoxColumn cNODataGridViewTextBoxColumn;
    private System.Windows.Forms.BindingSource pRODUCTBindingSource;
    private 기말_프로젝트_시작.DataSet1TableAdapters.PRODUCTTableAdapter pRODUCTTableAdapter;
    private 기말_프로젝트_시작.DataSet1 dataSet1 = new 기말_프로젝트_시작.DataSet1();
    System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();

    public CustomDatagridview()
    {
        this.pRODUCTBindingSource = new System.Windows.Forms.BindingSource(new System.ComponentModel.Container());
        this.pRODUCTTableAdapter = new 기말_프로젝트_시작.DataSet1TableAdapters.PRODUCTTableAdapter();
        this.pNODataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
        this.pKINDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewComboBoxColumn();
        this.pNAMEDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
        this.pPRICEDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
        this.pCOUNTDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
        this.pDATEDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
        this.pREFUNDCNTDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
        this.pSOLDOUTDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
        this.cNODataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();

        // 
        // pRODUCTTableAdapter
        // 
        this.pRODUCTTableAdapter.ClearBeforeFill = true;
        // 
        // dataSet1
        // 
        this.dataSet1.DataSetName = "DataSet1";
        this.dataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
        // 
        // pRODUCTBindingSource
        // 
        this.pRODUCTBindingSource.DataMember = "PRODUCT";
        this.pRODUCTBindingSource.DataSource = this.dataSet1;
        // 
        // pRODUCTTableAdapter
        // 
        this.pRODUCTTableAdapter.ClearBeforeFill = true;
        // 
        // pNODataGridViewTextBoxColumn
        // 
        this.pNODataGridViewTextBoxColumn.DataPropertyName = "P_NO";
        this.pNODataGridViewTextBoxColumn.HeaderText = "식별 번호";
        this.pNODataGridViewTextBoxColumn.Name = "pNODataGridViewTextBoxColumn";
        // 
        // pKINDDataGridViewTextBoxColumn
        // 
        this.pKINDDataGridViewTextBoxColumn.DataPropertyName = "P_KIND";
        this.pKINDDataGridViewTextBoxColumn.HeaderText = "종류";
        this.pKINDDataGridViewTextBoxColumn.Items.AddRange(new object[] {
            "음료수",
            "의류",
            "과일",
            "빵",
            "맥주",
            "커피",
            "과자",
            "시리얼",
            "라면",
            "즉석식품",
            "채소",
            "조미료",
            "육류",
            "생선",
            "해산물",
            "냉동",
            "견과류",
            "문구",
            "화장품",
            "건강식품"});
        this.pKINDDataGridViewTextBoxColumn.Name = "pKINDDataGridViewTextBoxColumn";
        this.pKINDDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
        this.pKINDDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
        // 
        // pNAMEDataGridViewTextBoxColumn
        // 
        this.pNAMEDataGridViewTextBoxColumn.DataPropertyName = "P_NAME";
        this.pNAMEDataGridViewTextBoxColumn.HeaderText = "이름";
        this.pNAMEDataGridViewTextBoxColumn.Name = "pNAMEDataGridViewTextBoxColumn";
        // 
        // pPRICEDataGridViewTextBoxColumn
        // 
        this.pPRICEDataGridViewTextBoxColumn.DataPropertyName = "P_PRICE";
        this.pPRICEDataGridViewTextBoxColumn.HeaderText = "가격";
        this.pPRICEDataGridViewTextBoxColumn.Name = "pPRICEDataGridViewTextBoxColumn";
        // 
        // pCOUNTDataGridViewTextBoxColumn
        // 
        this.pCOUNTDataGridViewTextBoxColumn.DataPropertyName = "P_COUNT";
        this.pCOUNTDataGridViewTextBoxColumn.HeaderText = "개수";
        this.pCOUNTDataGridViewTextBoxColumn.Name = "pCOUNTDataGridViewTextBoxColumn";
        // 
        // pDATEDataGridViewTextBoxColumn
        // 
        this.pDATEDataGridViewTextBoxColumn.DataPropertyName = "P_DATE";
        dataGridViewCellStyle1.Format = "d";
        dataGridViewCellStyle1.NullValue = null;
        this.pDATEDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle1;
        this.pDATEDataGridViewTextBoxColumn.HeaderText = "입고일";
        this.pDATEDataGridViewTextBoxColumn.Name = "pDATEDataGridViewTextBoxColumn";
        // 
        // pREFUNDCNTDataGridViewTextBoxColumn
        // 
        this.pREFUNDCNTDataGridViewTextBoxColumn.DataPropertyName = "P_REFUNDCNT";
        this.pREFUNDCNTDataGridViewTextBoxColumn.HeaderText = "환불 횟수";
        this.pREFUNDCNTDataGridViewTextBoxColumn.Name = "pREFUNDCNTDataGridViewTextBoxColumn";
        // 
        // pSOLDOUTDataGridViewTextBoxColumn
        // 
        this.pSOLDOUTDataGridViewTextBoxColumn.DataPropertyName = "P_SOLDOUT";
        this.pSOLDOUTDataGridViewTextBoxColumn.FalseValue = "0";
        this.pSOLDOUTDataGridViewTextBoxColumn.HeaderText = "판매 가능";
        this.pSOLDOUTDataGridViewTextBoxColumn.Name = "pSOLDOUTDataGridViewTextBoxColumn";
        this.pSOLDOUTDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
        this.pSOLDOUTDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
        this.pSOLDOUTDataGridViewTextBoxColumn.TrueValue = "1";
        // 
        // cNODataGridViewTextBoxColumn
        // 
        this.cNODataGridViewTextBoxColumn.DataPropertyName = "C_NO";
        this.cNODataGridViewTextBoxColumn.HeaderText = "판매자";
        this.cNODataGridViewTextBoxColumn.Name = "cNODataGridViewTextBoxColumn";

        this.AutoGenerateColumns = false;
        this.BackgroundColor = System.Drawing.Color.DarkSlateGray;
        this.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
        this.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.pNODataGridViewTextBoxColumn,
            this.pKINDDataGridViewTextBoxColumn,
            this.pNAMEDataGridViewTextBoxColumn,
            this.pPRICEDataGridViewTextBoxColumn,
            this.pCOUNTDataGridViewTextBoxColumn,
            this.pDATEDataGridViewTextBoxColumn,
            this.pREFUNDCNTDataGridViewTextBoxColumn,
            this.pSOLDOUTDataGridViewTextBoxColumn,
            this.cNODataGridViewTextBoxColumn});
        this.DataSource = this.pRODUCTBindingSource;
        this.Location = new System.Drawing.Point(0, 40);
        this.Name = "dataGridView1";
        this.RowTemplate.Height = 23;
        this.Size = new System.Drawing.Size(800, 430);
        this.TabIndex = 7;
        this.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick_2);
    }


    private void dataGridView1_CellContentClick_2(object sender, DataGridViewCellEventArgs e)
    {

    }
}