﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 기말_프로젝트_시작
{
    public partial class C_Review : Form
    {
        string USER;
        int REVIEW_NUM = 0;
        public C_Review(string C_NAME)
        {
            InitializeComponent();
            USER = C_NAME;
        }

        private void C_Review_Load(object sender, EventArgs e)
        {
            // TODO: 이 코드는 데이터를 'dataSet1.BUYING' 테이블에 로드합니다. 필요 시 이 코드를 이동하거나 제거할 수 있습니다.
            this.bUYINGTableAdapter.Fill(this.dataSet1.BUYING);
            // TODO: 이 코드는 데이터를 'dataSet1.REVIEW' 테이블에 로드합니다. 필요 시 이 코드를 이동하거나 제거할 수 있습니다.
            this.rEVIEWTableAdapter.Fill(this.dataSet1.REVIEW);
            productTableAdapter1.Fill(this.dataSet1.PRODUCT);

            // 필터링
            rEVIEWBindingSource1.Filter = "C_NO = '" + USER.Replace("'", "''") + "'"; // 내가 작성한 리뷰 : USER 필터링
            bUYINGBindingSource.Filter = "C_NO = '" + USER.Replace("'", "''") + "' AND B_OK = 'OK' AND REVIEW = '1'"; // 후기 작성 : USER + OK인 제품
            
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e) // 리뷰 작성하기 버튼
        {
            // 1. 식별 번호
            if (textBox1.Text == "")
            {
                MessageBox.Show("식별 번호를 입력해주세요.");
                return;
            }

            // 2. 상품 번호
            if (textBox3.Text == "")
            {
                MessageBox.Show("상품 번호를 입력해주세요.");
                return;
            }

            // 2. 별점 점수
            if (textBox4.Text == "")
            {
                MessageBox.Show("별점 점수를 입력해주세요.");
                return;
            }

            // 3. 리뷰 내용
            if (richTextBox1.Text == "")
            {
                MessageBox.Show("리뷰 내용을 입력해주세요.");
                return;
            }

            // BUYING 테이블에서 REVIEW 테이블로 복사
            try
            {
                foreach (DataRow mydataRow in dataSet1.Tables["BUYING"].Rows)
                {
                    // 1. BUYING : 리뷰 
                    // 리뷰 조건 : 사용자 + B_OK == "OK" + REVIEW == "1" // REVIEW 1 : 리뷰작성가능 // REVIEW 0 : 리뷰 작성한 상품
                    if (textBox1.Text == mydataRow["CART_NO"].ToString() && mydataRow["C_NO"].ToString() == USER && mydataRow["B_OK"].ToString() == "OK" && mydataRow["REVIEW"].ToString() == "1")
                    {
                        // REVIEW : 새로운 REVIEW 생성 : REVIEW_NO == MAX값
                        DataRow myNewDataRow = dataSet1.Tables["REVIEW"].NewRow(); // 임시 REVIEW 생성
                        var modifyNoRows = dataSet1.Tables["REVIEW"].AsEnumerable();
                        int maxModifyNo = modifyNoRows.Any() ? modifyNoRows.Max(r => int.Parse(r["REVIEW_NO"].ToString())) : 0;
                        string newModifyNo = (maxModifyNo + 1).ToString();
                        REVIEW_NUM = Convert.ToInt32(newModifyNo);

                        // REVIEW : 데이터 입력
                        myNewDataRow["REVIEW_NO"] = newModifyNo; // REFUND 식별 번호
                        myNewDataRow["C_NO"] = USER; // 사용자 이름
                        myNewDataRow["P_KIND"] = mydataRow["P_KIND"]; // 상품 종류
                        myNewDataRow["P_NO"] = mydataRow["P_NO"]; // 상품 번호
                        myNewDataRow["P_NAME"] = mydataRow["P_NAME"]; // 상품 이름
                        myNewDataRow["S_NO"] = mydataRow["S_NO"]; // 판매자
                        myNewDataRow["STAR"] = textBox4.Text; // 별점 점수
                        myNewDataRow["CONTENT"] = richTextBox1.Text;
                        myNewDataRow["REVIEW_DATE"] = DateTime.Now; // 환불 날짜
                        myNewDataRow["P_NAME"] = mydataRow["P_NAME"]; // 환불 날짜

                        dataSet1.Tables["REVIEW"].Rows.Add(myNewDataRow); // REVIEW에 데이터 추가
                    }
                }
                rEVIEWTableAdapter.Update(dataSet1.REVIEW); // REVIEW 업데이트


                // 2. BUYING 테이블에서 REVIEW 컬럼을 1 -> 0 으로 바꿔야함. : 리뷰 작성 완료함
                foreach (DataRow mydataRow in dataSet1.Tables["BUYING"].Rows) // CART 테이블 열 찾기
                {
                    // REVIEW 작성한 상품은 못 쓰도록 0으로 바꾸기
                    if (textBox1.Text == mydataRow["CART_NO"].ToString() && mydataRow["C_NO"].ToString() == USER && mydataRow["B_OK"].ToString() == "OK" && mydataRow["REVIEW"].ToString() == "1") 
                    {
                        mydataRow["REVIEW"] = "0"; // 0으로 변경
                    }
                }
                bUYINGTableAdapter.Update(dataSet1.BUYING);

                
                // 3. PRODUCT -> P_REVIEW ++
                foreach (DataRow mydataRow in dataSet1.Tables["PRODUCT"].Rows) // CART 테이블 열 찾기
                {
                    // REVIEW 작성한 상품은 못 쓰도록 0으로 바꾸기
                    // 조건 : 판매자 같고, 물건 번호가 같은 것
                    if (mydataRow["C_NO"].ToString() == USER && mydataRow["P_NO"].ToString() == textBox3.Text)
                    {
                        int a = Convert.ToInt32(mydataRow["P_REVIEW"].ToString());
                        mydataRow["P_REVIEW"] = a + 1;
                    }
                }
                bUYINGTableAdapter.Update(dataSet1.BUYING);
                

                textBox1.Text = "";
                textBox4.Text = "";
                richTextBox1.Text = "";


                MessageBox.Show("리뷰 번호 " + REVIEW_NUM + ", 리뷰 등록 완료!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("업데이트 중 오류가 발생했습니다: " + ex.Message);
            }

        }
    }
}
