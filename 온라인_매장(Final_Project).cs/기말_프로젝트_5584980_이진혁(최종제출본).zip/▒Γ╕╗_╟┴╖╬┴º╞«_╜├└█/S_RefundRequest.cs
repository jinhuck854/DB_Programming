﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 기말_프로젝트_시작
{
    public partial class S_RefundRequest : Form
    {
        string USER;

        int count = 0;
        public S_RefundRequest(string C_NAME)
        {
            InitializeComponent();
            USER = C_NAME;
        }

        private void S_RefundRequest_Load(object sender, EventArgs e)
        {
            // TODO: 이 코드는 데이터를 'dataSet1.REFUND' 테이블에 로드합니다. 필요 시 이 코드를 이동하거나 제거할 수 있습니다.
            this.rEFUNDTableAdapter.Fill(this.dataSet1.REFUND);
            productTableAdapter1.Fill(this.dataSet1.PRODUCT);
            customerTableAdapter1.Fill(this.dataSet1.CUSTOMER);
            buyingTableAdapter1.Fill(this.dataSet1.BUYING);

            rEFUNDBindingSource.Filter = "S_NO = '" + USER.Replace("'", "''") + "'"; // 판매자만 보이게 하기.

        }

        private void button2_Click(object sender, EventArgs e) // 환불 승인 요청
        {
            // 1. 식별 번호
            if (textBox1.Text == "")
            {
                MessageBox.Show("식별 번호를 입력해주세요");
                return;
            }

            // 2. 고객 번호
            if (textBox2.Text == "")
            {
                MessageBox.Show("고객 이름을 입력해주세요");
                return;
            }

            // 3. 상품 번호
            if (textBox3.Text == "")
            {
                MessageBox.Show("상품 번호를 입력해주세요");
                return;
            }

            // 4. 구매 개수
            if (textBox4.Text == "")
            {
                MessageBox.Show("구매 개수를 입력해주세요");
                return;
            }


            // 환불 요청 승인
            try
            {
                // 1. 환불 요청 승인 // 0 -> 1로
                foreach (DataRow mydataRow in dataSet1.Tables["REFUND"].Rows)
                { // 판매자, 구매자, 상품 번호, 
                    if (mydataRow["S_NO"].ToString() == USER &&
                        mydataRow["C_NO"].ToString() == textBox2.Text &&
                        mydataRow["P_NO"].ToString() == textBox3.Text &&
                        mydataRow["IS_OK"].ToString() == "0")
                    {
                        mydataRow["IS_OK"] = "1"; // IS_OK = 1 : 환불 승인 완료
                        // 
                        // count = Convert.ToInt32(mydataRow["B_COUNT"].ToString()); // 구매 횟수 저장하기.
                    }
                }
                rEFUNDTableAdapter.Update(this.dataSet1.REFUND); // REFUND 업데이트


                // 2. REFUND -> PRODUCT : P_REFUNDCNT ++
                // +) PRODUCT : P_SELL, REFUND 테이블의 P_SELL만큼 감소
                foreach (DataRow mydataRow in dataSet1.Tables["PRODUCT"].Rows)
                {
                    if (mydataRow["C_NO"].ToString() == USER && mydataRow["P_NO"].ToString() == textBox3.Text) // 상품 환불 횟수 올리고, 상품 재고 원래대로 돌리기
                    {
                        count = Convert.ToInt32(mydataRow["P_REFUNDCNT"].ToString()) + 1;
                        mydataRow["P_REFUNDCNT"] = count.ToString();

                        // 1. 기존 상품 개수 - 환불 상품 개수
                        mydataRow["P_SELL"] = Convert.ToInt32(mydataRow["P_SELL"]) - Convert.ToInt32(textBox4.Text); // REFUND 데이터에서 빼와야하는데

                        // 재고가 있을 경우, 판매 가능 여부에 체크 표시
                        if(mydataRow["P_SELL"] != mydataRow["P_COUNT"])
                        {
                            mydataRow["P_SOLDOUT"] = "1";
                        }
                    }

                }
                productTableAdapter1.Update(this.dataSet1.PRODUCT); // PRODUCT 업데이트

                count = 0;

                // 3. CUSTOMER -> C_REFUNDCNT ++
                foreach (DataRow mydataRow in dataSet1.Tables["CUSTOMER"].Rows)
                {
                    if (mydataRow["C_NO"].ToString() == textBox2.Text) // 사용자 환불 횟수 늘리기
                    {
                        count = Convert.ToInt32(mydataRow["C_REFUNDCNT"].ToString()) + 1;
                        mydataRow["C_REFUNDCNT"] = count.ToString();
                    }

                }
                customerTableAdapter1.Update(this.dataSet1.CUSTOMER); // CUSTOMER 업데이트


                // 4. BUYING -> "환불 완료"로 변경
                foreach (DataRow mydataRow in dataSet1.Tables["BUYING"].Rows)
                {
                    if (mydataRow["S_NO"].ToString() == USER &&
                        mydataRow["C_NO"].ToString() == textBox2.Text &&
                        mydataRow["P_NO"].ToString() == textBox3.Text &&
                        mydataRow["B_OK"].ToString() == "환불 요청 완료") // 판매자 + 구매자 + 상품 번호 + B_OK : 같아야함
                    {
                        mydataRow["B_OK"] = "환불 완료"; // B_OK = OK로 바꾸기
                    }
                }
                buyingTableAdapter1.Update(this.dataSet1.BUYING); // BUYING 업데이트

                // 초기화
                textBox1.Text = "";
                textBox2.Text = "";
                textBox3.Text = "";
                textBox4.Text = "";
                count = 0;

                MessageBox.Show("환불 요청 승인 완료!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("업데이트 중 오류가 발생했습니다: " + ex.Message);
            }
        }
    }
}
