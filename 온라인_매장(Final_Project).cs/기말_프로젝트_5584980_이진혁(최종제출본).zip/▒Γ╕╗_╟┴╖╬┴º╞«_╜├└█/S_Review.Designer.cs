﻿
namespace 기말_프로젝트_시작
{
    partial class S_Review
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.labelName = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.dataSet1 = new 기말_프로젝트_시작.DataSet1();
            this.rEVIEWBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.rEVIEWTableAdapter = new 기말_프로젝트_시작.DataSet1TableAdapters.REVIEWTableAdapter();
            this.sNODataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.rEVIEWNODataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cNODataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pKINDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pNODataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pNAMEDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cONTENTDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sTARDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.rEVIEWDATEDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rEVIEWBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // labelName
            // 
            this.labelName.AutoSize = true;
            this.labelName.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.labelName.ForeColor = System.Drawing.Color.DarkSlateBlue;
            this.labelName.Location = new System.Drawing.Point(350, 10);
            this.labelName.Name = "labelName";
            this.labelName.Size = new System.Drawing.Size(80, 21);
            this.labelName.TabIndex = 10;
            this.labelName.Text = "후기 보기";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.AntiqueWhite;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.sNODataGridViewTextBoxColumn,
            this.rEVIEWNODataGridViewTextBoxColumn,
            this.cNODataGridViewTextBoxColumn,
            this.pKINDDataGridViewTextBoxColumn,
            this.pNODataGridViewTextBoxColumn,
            this.pNAMEDataGridViewTextBoxColumn,
            this.cONTENTDataGridViewTextBoxColumn,
            this.sTARDataGridViewTextBoxColumn,
            this.rEVIEWDATEDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.rEVIEWBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(0, 40);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.RowTemplate.Height = 23;
            this.dataGridView1.Size = new System.Drawing.Size(800, 430);
            this.dataGridView1.TabIndex = 11;
            // 
            // dataSet1
            // 
            this.dataSet1.DataSetName = "DataSet1";
            this.dataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // rEVIEWBindingSource
            // 
            this.rEVIEWBindingSource.DataMember = "REVIEW";
            this.rEVIEWBindingSource.DataSource = this.dataSet1;
            // 
            // rEVIEWTableAdapter
            // 
            this.rEVIEWTableAdapter.ClearBeforeFill = true;
            // 
            // sNODataGridViewTextBoxColumn
            // 
            this.sNODataGridViewTextBoxColumn.DataPropertyName = "S_NO";
            this.sNODataGridViewTextBoxColumn.HeaderText = "판매자";
            this.sNODataGridViewTextBoxColumn.Name = "sNODataGridViewTextBoxColumn";
            // 
            // rEVIEWNODataGridViewTextBoxColumn
            // 
            this.rEVIEWNODataGridViewTextBoxColumn.DataPropertyName = "REVIEW_NO";
            this.rEVIEWNODataGridViewTextBoxColumn.HeaderText = "리뷰 번호";
            this.rEVIEWNODataGridViewTextBoxColumn.Name = "rEVIEWNODataGridViewTextBoxColumn";
            // 
            // cNODataGridViewTextBoxColumn
            // 
            this.cNODataGridViewTextBoxColumn.DataPropertyName = "C_NO";
            this.cNODataGridViewTextBoxColumn.HeaderText = "작성자";
            this.cNODataGridViewTextBoxColumn.Name = "cNODataGridViewTextBoxColumn";
            // 
            // pKINDDataGridViewTextBoxColumn
            // 
            this.pKINDDataGridViewTextBoxColumn.DataPropertyName = "P_KIND";
            this.pKINDDataGridViewTextBoxColumn.HeaderText = "상품 종류";
            this.pKINDDataGridViewTextBoxColumn.Name = "pKINDDataGridViewTextBoxColumn";
            // 
            // pNODataGridViewTextBoxColumn
            // 
            this.pNODataGridViewTextBoxColumn.DataPropertyName = "P_NO";
            this.pNODataGridViewTextBoxColumn.HeaderText = "상품 번호";
            this.pNODataGridViewTextBoxColumn.Name = "pNODataGridViewTextBoxColumn";
            // 
            // pNAMEDataGridViewTextBoxColumn
            // 
            this.pNAMEDataGridViewTextBoxColumn.DataPropertyName = "P_NAME";
            this.pNAMEDataGridViewTextBoxColumn.HeaderText = "상품 이름";
            this.pNAMEDataGridViewTextBoxColumn.Name = "pNAMEDataGridViewTextBoxColumn";
            // 
            // cONTENTDataGridViewTextBoxColumn
            // 
            this.cONTENTDataGridViewTextBoxColumn.DataPropertyName = "CONTENT";
            this.cONTENTDataGridViewTextBoxColumn.HeaderText = "내용";
            this.cONTENTDataGridViewTextBoxColumn.Name = "cONTENTDataGridViewTextBoxColumn";
            // 
            // sTARDataGridViewTextBoxColumn
            // 
            this.sTARDataGridViewTextBoxColumn.DataPropertyName = "STAR";
            this.sTARDataGridViewTextBoxColumn.HeaderText = "별점";
            this.sTARDataGridViewTextBoxColumn.Name = "sTARDataGridViewTextBoxColumn";
            // 
            // rEVIEWDATEDataGridViewTextBoxColumn
            // 
            this.rEVIEWDATEDataGridViewTextBoxColumn.DataPropertyName = "REVIEW_DATE";
            this.rEVIEWDATEDataGridViewTextBoxColumn.HeaderText = "리뷰 날짜";
            this.rEVIEWDATEDataGridViewTextBoxColumn.Name = "rEVIEWDATEDataGridViewTextBoxColumn";
            // 
            // S_Review
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(800, 470);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.labelName);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "S_Review";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "S_Review";
            this.Load += new System.EventHandler(this.S_Review_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rEVIEWBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelName;
        private System.Windows.Forms.DataGridView dataGridView1;
        private DataSet1 dataSet1;
        private System.Windows.Forms.BindingSource rEVIEWBindingSource;
        private DataSet1TableAdapters.REVIEWTableAdapter rEVIEWTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn sNODataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn rEVIEWNODataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cNODataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pKINDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pNODataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pNAMEDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cONTENTDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sTARDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn rEVIEWDATEDataGridViewTextBoxColumn;
    }
}