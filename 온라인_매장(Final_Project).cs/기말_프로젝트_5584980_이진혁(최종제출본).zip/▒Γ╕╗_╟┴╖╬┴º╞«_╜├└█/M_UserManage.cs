﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 기말_프로젝트_시작
{
    public partial class M_UserManage : Form
    {
        public M_UserManage()
        {
            InitializeComponent();
        }

        private void M_UserManage_Load(object sender, EventArgs e)
        {
            // TODO: 이 코드는 데이터를 'dataSet1.CUSTOMER' 테이블에 로드합니다. 필요 시 이 코드를 이동하거나 제거할 수 있습니다.
            this.cUSTOMERTableAdapter.Fill(this.dataSet1.CUSTOMER);

        }

        private void labelName_Click(object sender, EventArgs e)
        { //                                                                                       .
            MessageBox.Show("구분(0 = 관리자 // 1 = 고객 // 2 = 판매자)" + "                                     회원등급(0 = 관리자 // 1 = 일반 회원 // 2 = 우수 회원 // 3 = 불량 회원)");
        }

        private void button4_Click(object sender, EventArgs e) // 번호 검색
        {
            if (cUSTOMERBindingSource.Filter != null)
            {
                textBox1.Text = "";
                cUSTOMERBindingSource.RemoveFilter();
                button1.Text = "번호 검색";
            }
            else
            {
                cUSTOMERBindingSource.Filter = "C_NO LIKE '%" + textBox1.Text + "%'";
                button1.Text = "필터 해제";
            }
        }

        private void button2_Click(object sender, EventArgs e) // 이름 검색
        {
            if (cUSTOMERBindingSource.Filter != null)
            {
                textBox1.Text = "";
                cUSTOMERBindingSource.RemoveFilter();
                button2.Text = "이름 검색";
            }
            else
            {
                cUSTOMERBindingSource.Filter = "C_NAME LIKE '%" + textBox1.Text + "%'";
                button2.Text = "필터 해제";
            }
        }

        private void button3_Click(object sender, EventArgs e) // 로그아웃
        {
            MessageBox.Show("로그아웃 되었습니다.");
            Application.Exit(); // 모든 화면 닫기
        }

        private void button4_Click_1(object sender, EventArgs e) // 업데이트 버튼
        {
            try
            {
                this.cUSTOMERBindingSource.EndEdit();
                int ret = this.cUSTOMERTableAdapter.Update(this.dataSet1.CUSTOMER);
                if (ret > 0)
                    MessageBox.Show("업데이트 완료!");
            }
            catch
            {
                MessageBox.Show("업데이트가 실패했습니다.");
            }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
