﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 기말_프로젝트_시작
{
    public partial class C_Cart : Form
    {
        DataTable cartTable;
        DataTable productTable;

        string USER;
        int total;
        int count;
        int PRODUCT_CNT = 0;

        public C_Cart(string C_NAME)
        {
            InitializeComponent();
            USER = C_NAME;
        }

        private void C_Cart_Load(object sender, EventArgs e)
        {
            // TODO: 이 코드는 데이터를 'dataSet1.CART' 테이블에 로드합니다. 필요 시 이 코드를 이동하거나 제거할 수 있습니다.
            this.cARTTableAdapter.Fill(this.dataSet1.CART);
            cARTBindingSource1.Filter = "C_NO = '" + USER.Replace("'", "''") + "'";
            customerTableAdapter1.Fill(this.dataSet1.CUSTOMER);
            productTableAdapter1.Fill(this.dataSet1.PRODUCT);

            cartTable = dataSet1.Tables["CART"];
            productTable = dataSet1.Tables["PRODUCT"];

            total = 0;
            count = 0;
            listBox1.Items.Clear();
        }

        private void button5_Click(object sender, EventArgs e) // 구매하기 버튼
        {
            count = 0;
            if (checkBox1.Checked == false) // 동의서
            {
                MessageBox.Show("동의서에 체크해주세요");
                return;
            }

            // 1개씩 장바구니 -> BUYING 테이블로 이동
            try
            {
                List<string> productNo = new List<string>();
                List<string> productCnt = new List<string>(); // 물품 이름 + 물품 판매 개수 (여러개 구매할때)
                buyingTableAdapter1.Fill(dataSet1.BUYING); // 업데이트

                foreach (DataRow mydataRow in cartTable.Rows)
                {
                    if (mydataRow["C_NO"].ToString() == USER && mydataRow["CHOICE"].ToString() == "1")
                    {
                        // BUYING : 새로운 CART_NO 생성
                        DataRow myNewDataRow = dataSet1.Tables["BUYING"].NewRow(); // 임시 Buying 테이블 생성
                        var modifyNoRows = dataSet1.Tables["BUYING"].AsEnumerable();
                        int maxModifyNo = modifyNoRows.Any() ? modifyNoRows.Max(r => int.Parse(r["CART_NO"].ToString())) : 0;
                        string newModifyNo = (maxModifyNo + 1).ToString();
                        PRODUCT_CNT = Convert.ToInt32(newModifyNo);

                        // 데이터 입력
                        myNewDataRow["CART_NO"] = newModifyNo;
                        myNewDataRow["C_NO"] = USER;
                        myNewDataRow["P_KIND"] = mydataRow["P_KIND"];
                        myNewDataRow["P_NO"] = mydataRow["P_NO"];
                        myNewDataRow["P_NAME"] = mydataRow["P_NAME"];
                        myNewDataRow["REVIEW"] = mydataRow["P_NAME"];
                        myNewDataRow["S_NO"] = mydataRow["S_NO"];
                        myNewDataRow["B_DATE"] = dateTimePicker1.Value;
                        // 현재 상품의 B_COUNT(물품 구매 개수)가 2개 이상일 때, productCnt List로 넣어둠.
                        
                        if(Convert.ToInt32(mydataRow["B_COUNT"]) > 1) // 구매 물품이 여러개일 때
                        {
                            productCnt.Add(mydataRow["P_NO"].ToString() + "|" + mydataRow["B_COUNT"].ToString()); // P_NO랑 B_COUNT 같이 저장
                            myNewDataRow["B_COUNT"] = mydataRow["B_COUNT"];
                        }
                        else // 구매 물품이 1개일 때
                        {
                            myNewDataRow["B_COUNT"] = mydataRow["B_COUNT"];
                        }
                        myNewDataRow["B_PRICE"] = mydataRow["B_PRICE"];
                        myNewDataRow["B_OK"] = "NOT";
                        myNewDataRow["REVIEW"] = "1";

                        productNo.Add((string)mydataRow["P_No"]);

                        count++;
                        dataSet1.Tables["BUYING"].Rows.Add(myNewDataRow); // BUYING에 데이터 추가
                    }
                }
                buyingTableAdapter1.Update(dataSet1.BUYING); // BUYING 업데이트 : 데이터 추가

                // CART 데이터 삭제
                List<DataRow> rowsToDelete = new List<DataRow>();

                // CART에서 삭제할 행 추가
                foreach (DataRow mydataRow2 in dataSet1.Tables["CART"].Rows)
                {
                    if (mydataRow2["C_NO"].ToString() == USER && mydataRow2["CHOICE"].ToString() == "1")
                    {
                        // 삭제할 행 리스트에 추가합니다.
                        rowsToDelete.Add(mydataRow2);
                    }
                }
                customerTableAdapter1.Update(dataSet1.CUSTOMER);

                // 회원 구매횟수 + 1
                foreach(DataRow mydataRow3 in dataSet1.Tables["CUSTOMER"].Rows) 
                {
                    if (mydataRow3["C_NO"].ToString() == USER)
                    {
                        int a = Convert.ToInt32(mydataRow3["C_BUYCNT"]) + count; // a = 기존 값 + count(구매 개수)
                        mydataRow3["C_BUYCNT"] = a.ToString(); // C_BUTCNT a 입력
                    }
                }
                customerTableAdapter1.Update(dataSet1.CUSTOMER); // CUSTOMER 업데이트
                productTableAdapter1.Update(this.dataSet1.PRODUCT); // PRODUCT 업데이트 
                
                // CART 행 삭제
                foreach (DataRow row in rowsToDelete)
                {
                    row.Delete(); // DataRow의 Delete 메서드를 호출하여 표시합니다.
                }

                cARTTableAdapter.Update(this.dataSet1.CART); // CART 업데이트 : 데이터 삭제
                MessageBox.Show("번호 " + PRODUCT_CNT +", 구매 완료!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("업데이트 중 오류가 발생했습니다: " + ex.Message);
            }
        }

        private void button1_Click(object sender, EventArgs e) // 상품 제거하기
        {
            try
            {
                // CART 데이터 삭제
                List<DataRow> rowsToDelete = new List<DataRow>();

                // CART 검사
                foreach (DataRow mydataRow2 in dataSet1.Tables["CART"].Rows)
                {
                    if (mydataRow2["C_NO"].ToString() == USER && mydataRow2["CHOICE"].ToString() == "1")
                    {
                        // 삭제할 행 리스트에 추가합니다.
                        rowsToDelete.Add(mydataRow2);
                    }
                }

                foreach (DataRow row in rowsToDelete)
                {
                    row.Delete(); // DataRow의 Delete 메서드를 호출하여 표시합니다.
                }
                cARTTableAdapter.Update(this.dataSet1.CART); // CART 업데이트 : 데이터 삭제
                MessageBox.Show("장바구니 물건 삭제");
            }
            catch (Exception ex)
            {
                MessageBox.Show("업데이트 중 오류가 발생했습니다: " + ex.Message);
            }
            
        }

        private void button2_Click(object sender, EventArgs e) // 가격 측정하기
        {
            // 2. 결제 가격
            // CART에서 고객 ID 찾기
            foreach (DataRow mydataRow in cartTable.Rows)
            {
                if (mydataRow["C_NO"].ToString() == USER && mydataRow["CHOICE"].ToString() == "1") // C_NO == USER 찾기
                {
                    int bTotalPrice;

                    string price = mydataRow["B_TOTAL_PRICE"].ToString().Replace(",", "").Replace("$", "");
                    if (int.TryParse(price, out bTotalPrice))
                    {
                        total += bTotalPrice;
                    }
                }
            }
            textBox1.Text = total.ToString();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
