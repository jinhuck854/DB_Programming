﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 기말_프로젝트_시작
{
    public partial class M_ProductDetail : Form
    {
        public M_ProductDetail()
        {
            InitializeComponent();
        }

        private void M_ProductDetail_Load(object sender, EventArgs e)
        {
            // TODO: 이 코드는 데이터를 'dataSet1.BUYING_CUSTOMER' 테이블에 로드합니다. 필요 시 이 코드를 이동하거나 제거할 수 있습니다.
            this.bUYING_CUSTOMERTableAdapter.Fill(this.dataSet1.BUYING_CUSTOMER);
            // TODO: 이 코드는 데이터를 'dataSet1.BUYING' 테이블에 로드합니다. 필요 시 이 코드를 이동하거나 제거할 수 있습니다.
            this.bUYINGTableAdapter.Fill(this.dataSet1.BUYING);
            // TODO: 이 코드는 데이터를 'dataSet11.PRODUCT' 테이블에 로드합니다. 필요 시 이 코드를 이동하거나 제거할 수 있습니다.
            this.pRODUCTTableAdapter.Fill(this.dataSet11.PRODUCT);
            // TODO: 이 코드는 데이터를 'dataSet1.PRODUCT' 테이블에 로드합니다. 필요 시 이 코드를 이동하거나 제거할 수 있습니다.
            // this.pRODUCTTableAdapter.Fill(this.dataSet1.PRODUCT);

        }

        private void labelName_Click(object sender, EventArgs e)
        {

        }

        private void chart1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e) // 새로고침
        {
            // TODO: 이 코드는 데이터를 'dataSet1.BUYING_CUSTOMER' 테이블에 로드합니다. 필요 시 이 코드를 이동하거나 제거할 수 있습니다.
            this.bUYING_CUSTOMERTableAdapter.Fill(this.dataSet1.BUYING_CUSTOMER);
            // TODO: 이 코드는 데이터를 'dataSet1.BUYING' 테이블에 로드합니다. 필요 시 이 코드를 이동하거나 제거할 수 있습니다.
            this.bUYINGTableAdapter.Fill(this.dataSet1.BUYING);
            // TODO: 이 코드는 데이터를 'dataSet11.PRODUCT' 테이블에 로드합니다. 필요 시 이 코드를 이동하거나 제거할 수 있습니다.
            this.pRODUCTTableAdapter.Fill(this.dataSet11.PRODUCT);
            // TODO: 이 코드는 데이터를 'dataSet1.PRODUCT' 테이블에 로드합니다. 필요 시 이 코드를 이동하거나 제거할 수 있습니다.
            // this.pRODUCTTableAdapter.Fill(this.dataSet1.PRODUCT);
        }
    }
}
