﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 기말_프로젝트_시작
{
    public partial class M_ProductStatistics : Form
    {
        
        DataTable buyingTable = new DataTable();

        public M_ProductStatistics()
        {
            InitializeComponent();
        }

        private void labelName_Click(object sender, EventArgs e)
        {

        }

        private void M_ProductStatistics_Load(object sender, EventArgs e)
        {
            // TODO: 이 코드는 데이터를 'dataSet1.P_REVIEW' 테이블에 로드합니다. 필요 시 이 코드를 이동하거나 제거할 수 있습니다.
            this.p_REVIEWTableAdapter.Fill(this.dataSet1.P_REVIEW);
            // TODO: 이 코드는 데이터를 'dataSet1.P_REFUND' 테이블에 로드합니다. 필요 시 이 코드를 이동하거나 제거할 수 있습니다.
            this.p_REFUNDTableAdapter.Fill(this.dataSet1.P_REFUND);
            this.dAILYSALESTableAdapter.Fill(this.dataSet11.DAILYSALES);
            // TODO: 이 코드는 데이터를 'dataSet1.WEEKLYSALES' 테이블에 로드합니다. 필요 시 이 코드를 이동하거나 제거할 수 있습니다.
            this.wEEKLYSALESTableAdapter.Fill(this.dataSet1.WEEKLYSALES);
            // TODO: 이 코드는 데이터를 'dataSet1.DAYOFWEEKSALES' 테이블에 로드합니다. 필요 시 이 코드를 이동하거나 제거할 수 있습니다.
            this.dAYOFWEEKSALESTableAdapter.Fill(this.dataSet1.DAYOFWEEKSALES);
            // TODO: 이 코드는 데이터를 'dataSet1.DAILYSALES' 테이블에 로드합니다. 필요 시 이 코드를 이동하거나 제거할 수 있습니다.
            this.dAILYSALESTableAdapter.Fill(this.dataSet1.DAILYSALES);
            // TODO: 이 코드는 데이터를 'dataSet1.PRODUCT' 테이블에 로드합니다. 필요 시 이 코드를 이동하거나 제거할 수 있습니다.
            this.pRODUCTTableAdapter.Fill(this.dataSet1.PRODUCT);
            // TODO: 이 코드는 데이터를 'dataSet1.P_SELL_KIND' 테이블에 로드합니다. 필요 시 이 코드를 이동하거나 제거할 수 있습니다.
            this.p_SELL_KINDTableAdapter.Fill(this.dataSet1.P_SELL_KIND);

            this.chart1.ChartAreas["ChartArea1"].AxisX.Interval = 1; // 판매량
            this.chart2.ChartAreas["ChartArea1"].AxisX.Interval = 1; // 판매액
            this.chart6.ChartAreas["ChartArea1"].AxisX.Interval = 1; // 판매액
            this.chart4.ChartAreas["ChartArea1"].AxisX.Interval = 1; // 판매액
            this.chart5.ChartAreas["ChartArea1"].AxisX.Interval = 1; // 날짜 선택별 판매액
            this.chart3.ChartAreas["ChartArea1"].AxisX.Interval = 1; // 환불 개수
            this.chart7.ChartAreas["ChartArea1"].AxisX.Interval = 1; // 환불 개수

            buyingTable = dataSet1.Tables["DAILYSALES"];
        }

        private void chart1_Click(object sender, EventArgs e)
        {

        }

        private void chart1_Click_1(object sender, EventArgs e) // 차트
        {

        }

        private void chart2_Click(object sender, EventArgs e)
        {

        }

        private void chart5_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e) // 새로고침
        {
            this.dAILYSALESTableAdapter.Fill(this.dataSet11.DAILYSALES);
            // TODO: 이 코드는 데이터를 'dataSet1.WEEKLYSALES' 테이블에 로드합니다. 필요 시 이 코드를 이동하거나 제거할 수 있습니다.
            this.wEEKLYSALESTableAdapter.Fill(this.dataSet1.WEEKLYSALES);
            // TODO: 이 코드는 데이터를 'dataSet1.DAYOFWEEKSALES' 테이블에 로드합니다. 필요 시 이 코드를 이동하거나 제거할 수 있습니다.
            this.dAYOFWEEKSALESTableAdapter.Fill(this.dataSet1.DAYOFWEEKSALES);
            // TODO: 이 코드는 데이터를 'dataSet1.DAILYSALES' 테이블에 로드합니다. 필요 시 이 코드를 이동하거나 제거할 수 있습니다.
            this.dAILYSALESTableAdapter.Fill(this.dataSet1.DAILYSALES);
            // TODO: 이 코드는 데이터를 'dataSet1.PRODUCT' 테이블에 로드합니다. 필요 시 이 코드를 이동하거나 제거할 수 있습니다.
            this.pRODUCTTableAdapter.Fill(this.dataSet1.PRODUCT);
            // TODO: 이 코드는 데이터를 'dataSet1.P_SELL_KIND' 테이블에 로드합니다. 필요 시 이 코드를 이동하거나 제거할 수 있습니다.
            this.p_SELL_KINDTableAdapter.Fill(this.dataSet1.P_SELL_KIND);

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void chart1_Click_2(object sender, EventArgs e)
        {

        }

        private void chart2_Click_1(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e) // 연습용 클릭하기
        {
            chart5.Series.Clear();

            DateTime startDate = dateTimePicker3.Value.Date;
            DateTime endDate = dateTimePicker4.Value.Date.AddDays(1);

            DataRow[] mydata = buyingTable.Select("SaleDate >= #" + startDate.ToString("yyyy-MM-dd") + "# AND SaleDate < #" + endDate.ToString("yyyy-MM-dd") + "#");
            var series = chart5.Series.Add("TotalSales");

            foreach (DataRow mydataRow in mydata)
            {
                series.Points.AddXY(mydataRow["SaleDate"], mydataRow["TotalSales"]);

            }

            chart5.Series[0].Color = Color.Red;
            chart5.DataBind();
        }
    }
}
