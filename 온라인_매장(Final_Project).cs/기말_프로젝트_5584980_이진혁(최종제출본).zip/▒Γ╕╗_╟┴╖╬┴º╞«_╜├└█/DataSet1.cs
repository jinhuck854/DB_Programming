﻿namespace 기말_프로젝트_시작
{


    public partial class DataSet1
    {
        partial class BUYINGDataTable
        {
        }
    }
}
