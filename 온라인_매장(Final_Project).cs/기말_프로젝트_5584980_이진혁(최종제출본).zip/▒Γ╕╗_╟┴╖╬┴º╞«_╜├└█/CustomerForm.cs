﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 기말_프로젝트_시작
{
    public partial class CustomerForm : Form
    {
        DataTable userTable;

        string USER;
        public CustomerForm(string C_NAME)
        {
            InitializeComponent();
            USER = C_NAME;
            loadform(new C_PopularProduct());
        }

        public void loadform(object Form) // 로딩
        {
            if (this.panelMain.Controls.Count > 0)
            {
                this.panelMain.Controls.RemoveAt(0);
            }
            Form f = Form as Form;
            f.TopLevel = false;
            f.Dock = DockStyle.Fill;
            this.panelMain.Controls.Add(f);
            this.panelMain.Tag = f;
            f.Show();

            textBox1.Text = USER + "님 환영합니다!";

            userTable = dataSet11.Tables["CUSTOMER"]; // CUSTOMER 데이터 가져옴
        }

        private void CustomerForm_Load(object sender, EventArgs e)
        {

        }

        private void panelMain_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panelHeader_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panelSide_Paint(object sender, PaintEventArgs e)
        {

        }


        private void button9_Click(object sender, EventArgs e) // 닫기 버튼
        {
            Application.Exit(); // 모든 화면 닫기
        }

        private void button8_Click(object sender, EventArgs e) // 인기 상품
        {
            loadform(new C_PopularProduct());
        }

        private void button1_Click(object sender, EventArgs e) // 상품 둘러보기
        {
            loadform(new C_Search(USER));
        }

        private void button6_Click(object sender, EventArgs e) // 장바구니
        {
            loadform(new C_Cart(USER));
        }

        private void button3_Click(object sender, EventArgs e) // 구매 내역
        {
            loadform(new C_BuyingDetail(USER));
        }

        private void button7_Click(object sender, EventArgs e) // 후기 검색
        {
            loadform(new C_Review(USER));
        }

        private void button2_Click(object sender, EventArgs e) // 회원 탈퇴
        {
            // 이미지_링크-https://icons8.kr/icon/83238/%EC%98%81%EC%9B%90%ED%9E%88-%EC%82%AD%EC%A0%9C
            loadform(new C_LeaveUser(USER)); // C_NO을 줌.
            // USER : 유저 이름 (C_NO);

            /*
            foreach (DataRow mydataRow in productTable.Rows) // P_PRICE 찾기
            {
                if (mydataRow["P_KIND"].ToString() == textBox2.Text && mydataRow["P_NO"].ToString() == textBox3.Text)
                {
                    textBox4.Text = mydataRow["P_PRICE"].ToString();
                    break;
                }
                else
                {
                    textBox4.Text = "";
                }
            }
            */
        }

        
    }
}
