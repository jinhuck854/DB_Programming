﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 기말_프로젝트_시작
{
    public partial class RegistrationForm : Form
    {
        DataTable usertable;
        int flag = 0;

        public RegistrationForm()
        {
            InitializeComponent();

            customerTableAdapter1.Fill(dataSet11.CUSTOMER);
            usertable = dataSet11.Tables["CUSTOMER"];
        }

        private void RegistrationForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Complete !");
        }

        private void labelID_Click(object sender, EventArgs e)
        {

        }

        private void textBoxID_TextChanged(object sender, EventArgs e)
        {

        }

        private void RegistrationForm_Load(object sender, EventArgs e)
        {

        }

        private void button_ID_Check_Click(object sender, EventArgs e) // 중복 확인 버튼
        {
            DataTable mytable = dataSet11.Tables["CUSTOMER"];
            DataRow found = mytable.Rows.Find(textBoxID.Text); // 아이디 체크

            if (found != null) // 중복 O
            {
                MessageBox.Show("이미 사용중인 아이디입니다.");
            }
            else // 중복 X
            {
                MessageBox.Show("사용가능한 아이디입니다.");
                flag = 1; // flag 토글
            }
        }

        private void buttonRegistration_Click(object sender, EventArgs e) // 회원 가입 버튼
        {
            int check = 0; // 필수 체크 카운트
            DataRow myNewDataRow = usertable.NewRow(); // 임시 DB

            // 1. 아이디 체크
            if (textBoxID.Text == "") // 아이디 미입력
            {
                MessageBox.Show("아이디를 입력해주세요");
                return;
            }
            else if (flag == 0) // 아이디 중복 입력
            {
                MessageBox.Show("아이디 중복확인을 해주세요");
                return;
            }
            else // 통과
            {
                myNewDataRow["C_NO"] = textBoxID.Text;
                check += 1;
            }

            // 2. 비밀번호 체크
            if (textBoxPassword.Text == "") // 비밀번호 미입력
            {
                MessageBox.Show("비밀번호를 입력해주세요");
                return;
            }
            else // 통과
            {
                myNewDataRow["C_PASSWORD"] = textBoxPassword.Text;
                check += 1;
            }

            // 3. 비밀번호 중복 체크
            if (textBoxPassword.Text != textBoxPasswordCheck.Text) // 미일치
            {
                MessageBox.Show("비밀번호가 일치하지 않습니다");
                return;
            }

            // 4. 이름 체크
            if (textBoxName.Text == "") // 이름 미입력
            {
                MessageBox.Show("이름을 입력해주세요");
                // return;
            }
            else // 통과
            {
                myNewDataRow["C_NAME"] = textBoxName.Text;
                check += 1;
            }

            // 5. 주소 체크
            if (textBoxAddress.Text == "") // 주소 미입력
            {
                MessageBox.Show("주소를 입력해주세요");
                return;
            }
            else // 통과
            {
                myNewDataRow["C_ADDR"] = textBoxAddress.Text;
                check += 1;
            }


            // 6. 전화번호 체크
            if (textBoxPhoneNum.Text == "") // 번호 미입력
            {
                MessageBox.Show("전화번호를 입력해주세요");
                return;
            }
            else // 통과
            {
                myNewDataRow["C_PHONE"] = textBoxPhoneNum.Text;
                check += 1;
            }

            // 7. 성별 체크
            if (comboBoxGender.SelectedItem == null) // 성별 미체크
            {
                MessageBox.Show("성별을 선택하여주세요");
                return;
            }
            else // 통과
            {
                myNewDataRow["C_GENDER"] = comboBoxGender.SelectedItem.ToString();
                check += 1;
            }


            // +) 생일 입력
            myNewDataRow["C_BIRTHDAY"] = bIRTHDateTimePicker.Value;

            // +) 이메일 입력
            if (textBoxEmail.Text != "")
                myNewDataRow["C_EMAIL"] = textBoxEmail.Text;

            // 일반 회원 Or 판매자 구분
            if (checkBox1.Checked == true)
            {
                myNewDataRow["C_LEVEL"] = "2"; // 판매자
            }
            else 
            {
                myNewDataRow["C_LEVEL"] = "1"; // 일반 회원
            }
            
            myNewDataRow["C_GRADE"] = 1; // 일반 등급 // Not 우수고객, 불량고객
            myNewDataRow["C_BUYCNT"] = 0; // 구매 횟수 0으로 시작
            myNewDataRow["C_REFUNDCNT"] = 0; // 환불 횟수 0으로 시작

            if (check >= 6) // 필수사항 7개 모두 완료
            {
                usertable.Rows.Add(myNewDataRow); // 데이터 입력
                MessageBox.Show("가입을 축하드립니다");
                customerTableAdapter1.Update(dataSet11.CUSTOMER); // 회원 추가
                LoginForm showform = new LoginForm();
                this.Visible = false;
                showform.Show();
            }
            else
            {
                MessageBox.Show("다시 확인해주세요");
                check = 0;
            }
        }

        private void label11_Click(object sender, EventArgs e)
        {
            
        }

        private void Form_Closing(object sender, EventArgs e)
        {
            Application.Exit(); // 모든 화면 닫기
        }
    }
}
