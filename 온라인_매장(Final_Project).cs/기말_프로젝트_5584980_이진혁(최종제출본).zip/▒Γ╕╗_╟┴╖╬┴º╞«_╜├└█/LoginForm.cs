﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 기말_프로젝트_시작
{
    public partial class LoginForm : Form
    {

        DataTable usertable; // usertable
        static public string C_NO; // 유저 아이디 저장

        public LoginForm()
        {
            InitializeComponent();

            
            customerTableAdapter1.Fill(dataSet11.CUSTOMER);
            usertable = dataSet11.Tables["CUSTOMER"];
        }

        private void LoginForm_Load(object sender, EventArgs e) // 시작
        {

        }

        private void LoginForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            // this.Close();
        }
        
        private void button1_Click(object sender, EventArgs e) // 로그인 버튼
        {
            
            string ID = textBoxID.Text;
            string PW = textBoxPW.Text;
            int flag = 0; // 0 = 로그인 실패 // 1 = 로그인 성공

            foreach(DataRow mydataRow in usertable.Rows)
            {
                if(mydataRow["C_NO"].ToString() == textBoxID.Text && mydataRow["C_GRADE"].ToString() == "3")
                {
                    MessageBox.Show("죄송합니다. 서비스 제한 대상입니다.");
                    Application.Exit(); // 모든 화면 닫기
                    break;
                }

                if(mydataRow["C_NO"].ToString() == ID) // ID 일치
                {
                    if(mydataRow["C_PASSWORD"].ToString() == PW) // PW 일치
                    {
                        if (mydataRow["C_LEVEL"].ToString() == "0") // 관리자 로그인
                        {
                            MessageBox.Show("관리자 로그인");
                            this.Visible = false;
                            ManagerForm showform = new ManagerForm();
                            showform.Show();
                            flag = 1;
                            break;
                        }
                        else if (mydataRow["C_LEVEL"].ToString() == "1") // 일반 고객 로그인
                        {
                            C_NO = mydataRow["C_NO"].ToString();
                            MessageBox.Show(C_NO + " " + "회원님 환영합니다 !");
                            this.Visible = false;
                            CustomerForm showform = new CustomerForm(C_NO);
                            showform.Owner = this; // 모달창 Owner로 지정
                            showform.Show();
                            flag = 1;
                            break;
                        }
                        else if (mydataRow["C_LEVEL"].ToString() == "2") // 판매자 로그인
                        {
                            C_NO = mydataRow["C_NO"].ToString();
                            MessageBox.Show("판매자 로그인");
                            this.Visible = false;
                            SellerForm showform = new SellerForm(C_NO);
                            showform.Show();
                            flag = 1;
                            break;
                        }
                    }
                    else
                    {
                        flag = 0;
                    }
                }
                else
                {
                    flag = 0;
                }
            }

            if(flag == 0)
            {
                MessageBox.Show("아이디와 비밀번호가 일치하지 않습니다. ");
            }
            
        }

        private void button2_Click(object sender, EventArgs e) // 회원가입 버튼
        {
            RegistrationForm showform = new RegistrationForm();
            this.Visible = false;
            showform.Show();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e) // ID TextBox
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e) // PW TextBox
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void Form_Closing(object sender, EventArgs e) // 닫을 때
        {
            Application.Exit(); // 모든 화면 닫기
        }
    }
}
