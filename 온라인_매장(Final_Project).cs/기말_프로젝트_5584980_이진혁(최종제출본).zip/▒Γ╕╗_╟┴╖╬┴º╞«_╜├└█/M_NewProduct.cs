﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 기말_프로젝트_시작
{
    public partial class M_NewProduct : Form
    {
        DataTable productTable;
        int flag = -1; // 새로운 물건인지, 입고인지 체크
        // flag = 체크 X
        // flag = 0 : 입고
        // flag = 1 : 새로운 물건

        public M_NewProduct()
        {
            InitializeComponent();
        }

        private void M_NewProduct_Load(object sender, EventArgs e)
        {
            this.pRODUCTTableAdapter.Fill(this.dataSet1.PRODUCT);
            // TODO: 이 코드는 데이터를 'dataSet1.PRODUCT' 테이블에 로드합니다. 필요 시 이 코드를 이동하거나 제거할 수 있습니다.

            productTable = dataSet1.Tables["PRODUCT"];
        }

        private void labelName_Click(object sender, EventArgs e)
        {
            
        }

        private void button2_Click_1(object sender, EventArgs e) // 신규 상품 등록 및 공지 버튼
        {
            DataRow myNewDataRow = productTable.NewRow(); // 임시 DB
            int check = 0; // 필수 체크 카운트

            // 1. 식별 번호
            if (textBox2.Text == "") // 1. 식별 번호 입력
            {
                MessageBox.Show("식별 번호를 입력해주세요");
                return;
            }
            else // 통과
            {
                myNewDataRow["P_NO"] = textBox2.Text;
                check += 1;
            }

            // 2. 상품 종류
            if (flag == 1 && textBox3.Text == "") // 2. 상품 종류 입력
            {
                MessageBox.Show("상품 종류를 입력해주세요");
                return;
            }
            else // 통과
            {
                myNewDataRow["P_KIND"] = textBox3.Text;
                check += 1;
            }

            // 3. 상품 이름
            if (flag == 1 && textBox4.Text == "") // 3. 상품 이름 입력
            {
                MessageBox.Show("상품 이름을 입력해주세요");
                return;
            }
            else // 통과
            {
                myNewDataRow["P_NAME"] = textBox4.Text;
                check += 1;
            }

            // 4. 상품 가격
            if (flag == 1 && textBox5.Text == "") // 4. 상품 가격 입력
            {
                MessageBox.Show("상품 가격을 입력해주세요");
                return;
            }
            else // 통과
            {
                myNewDataRow["P_PRICE"] = textBox5.Text;
                check += 1;
            }

            // 5. 상품 개수
            if (textBox6.Text == "") // 5. 상품 개수 입력
            {
                MessageBox.Show("상품 개수를 입력해주세요");
                return;
            }
            else // 통과
            {
                myNewDataRow["P_COUNT"] = textBox6.Text;
                check += 1;
            }

            // 6. 판매자
            if (flag == 1 && textBox7.Text == "") // 6. 판매자 입력
            {
                MessageBox.Show("판매자를 입력해주세요");
                return;
            }
            else // 통과
            {
                myNewDataRow["C_NO"] = textBox7.Text;
                check += 1;
            }

            if(flag == -1)
            {
                MessageBox.Show("신규 상품 추가인지 기존 상품 입고인지 확인해주세요.");
            }
            else if(flag == 0) // 기존 상품 재고 추가
            {
                textBox3.Enabled = false;
                textBox4.Enabled = false;
                textBox5.Enabled = false;
                textBox7.Enabled = false;
                // PRODUCT -> P_NO를 찾고, P_NO의 P_COUNT 증가
                foreach (DataRow mydataRow in dataSet1.Tables["PRODUCT"].Rows)
                {
                    if (mydataRow["P_NO"].ToString() == textBox2.Text)
                    {
                        int a = Convert.ToInt32(mydataRow["P_COUNT"].ToString());
                        mydataRow["P_COUNT"] = a + Convert.ToInt32(textBox6.Text);

                        // 재고가 있을 경우, 판매 가능 여부에 체크 표시
                        if (mydataRow["P_SELL"] != mydataRow["P_COUNT"]) // 판매 가능 개수 != 판매한 개수
                        {
                            mydataRow["P_SOLDOUT"] = "1";
                        }
                        else if(mydataRow["P_SELL"] == mydataRow["P_COUNT"]) // 품절 : 판매 가능 개수 == 판매한 개수
                        {
                            mydataRow["P_SOLDOUT"] = "0";
                        }
                    }
                }
                pRODUCTTableAdapter.Update(dataSet1.PRODUCT);

                MessageBox.Show("기존 상품의 재고가 추가되었습니다.");

                textBox3.Enabled = true;
                textBox4.Enabled = true;
                textBox5.Enabled = true;
                textBox7.Enabled = true;
                textBox2.Text = "";
                textBox6.Text = "";

                // 2. PRODUCT -> P_COUNT > P_SELL
                foreach (DataRow mydataRow in dataSet1.Tables["PRODUCT"].Rows)
                {
                    if (mydataRow["P_NO"].ToString() == textBox2.Text)
                        {
                        int count = Convert.ToInt32(mydataRow["P_REFUNDCNT"].ToString()) + 1;
                        mydataRow["P_COUNT"] = count.ToString();

                        // 1. 기존 상품 개수 - 환불 상품 개수

                        
                    }

                }
                pRODUCTTableAdapter.Update(this.dataSet1.PRODUCT); // PRODUCT 업데이트

                return;
            }
            else if(flag != 0 && check >= 6) // 신규 상품 재고 추가
            {
                // 이 외 Default 데이터 입력
                myNewDataRow["P_DATE"] = DateTime.Now; // 입고일
                myNewDataRow["P_REFUNDCNT"] = 0; // 환불 횟수
                myNewDataRow["P_SELL"] = 0; // 판매 개수
                myNewDataRow["P_SOLDOUT"] = 1; // 판매 가능
                myNewDataRow["P_REVIEW"] = 0; // 리뷰

                productTable.Rows.Add(myNewDataRow); // 데이터 입력
                pRODUCTTableAdapter.Update(this.dataSet1.PRODUCT); // 업데이트 
                // dataSet1.Tables["P_PRODUCT"].Rows.Add(myNewDataRow); // NEW PRODUCT 테이블 열 추가 완료


                // 모든 textBox 초기화
                textBox2.Text = "";
                textBox3.Text = "";
                textBox4.Text = "";
                textBox5.Text = "";
                textBox6.Text = "";
                textBox7.Text = "";

                MessageBox.Show("신규 상품이 등록되었습니다.");
            }
        }

        private void button5_Click(object sender, EventArgs e) // 신규 상품 추가 또는 기존 상품 재고 입고인지 확인
        {
            DataTable mytable = dataSet1.Tables["PRODUCT"];
            string filterExpression = string.Format("P_NO = '{0}'", textBox2.Text.Replace("'", "''"));
            DataRow[] found = mytable.Select(filterExpression);
            // DataRow[] found = mytable.Select(textBox2.Text); // 식별 번호

            if (found.Length > 0) // 중복인지 확인
            {
                MessageBox.Show("기존 상품 입고입니다.");
                flag = 0;
            }
            else // 중복 X
            {
                MessageBox.Show("신규 상품 추가입니다.");
                flag = 1; // flag 토글
            }
        }

        private void button1_Click(object sender, EventArgs e) // 업데이트 버튼
        {
            try
            {
                this.pRODUCTBindingSource.EndEdit();
                int ret = this.pRODUCTTableAdapter.Update(this.dataSet1.PRODUCT);
                if (ret > 0)
                    MessageBox.Show("업데이트 완료!");
            }
            catch
            {
                MessageBox.Show("업데이트가 실패했습니다.");
            }
        }

        private void button4_Click(object sender, EventArgs e) // 종류 검색
        {
            if (pRODUCTBindingSource.Filter != null)
            {
                textBox1.Text = "";
                pRODUCTBindingSource.RemoveFilter();
                button4.Text = "종류 검색";
            }
            else
            {
                pRODUCTBindingSource.Filter = "P_KIND LIKE '%" + textBox1.Text + "%'";
                button4.Text = "필터 해제";
            }
        }

        private void button3_Click(object sender, EventArgs e) // 이름 검색
        {
            if (pRODUCTBindingSource.Filter != null)
            {
                textBox1.Text = "";
                pRODUCTBindingSource.RemoveFilter();
                button3.Text = "이름 검색";
            }
            else
            {
                pRODUCTBindingSource.Filter = "P_NAME LIKE '%" + textBox1.Text + "%'";
                button3.Text = "필터 해제";
            }
        }
    }
}
