﻿
namespace 기말_프로젝트_시작
{
    partial class C_PopularProduct
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea2 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend2 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.labelName = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.dataSet1 = new 기말_프로젝트_시작.DataSet1();
            this.pMODIFYBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.p_MODIFYTableAdapter = new 기말_프로젝트_시작.DataSet1TableAdapters.P_MODIFYTableAdapter();
            this.pKINDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pNODataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pNAMEDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pREPRICEDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nEXTPRICEDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.pTOP10SELLBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.p_TOP_10_SELLTableAdapter = new 기말_프로젝트_시작.DataSet1TableAdapters.P_TOP_10_SELLTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pMODIFYBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pTOP10SELLBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // labelName
            // 
            this.labelName.AutoSize = true;
            this.labelName.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.labelName.ForeColor = System.Drawing.Color.DarkSlateBlue;
            this.labelName.Location = new System.Drawing.Point(350, 10);
            this.labelName.Name = "labelName";
            this.labelName.Size = new System.Drawing.Size(140, 21);
            this.labelName.TabIndex = 15;
            this.labelName.Text = "할인 및 인기 상품";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.AntiqueWhite;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.pKINDDataGridViewTextBoxColumn,
            this.pNODataGridViewTextBoxColumn,
            this.pNAMEDataGridViewTextBoxColumn,
            this.pREPRICEDataGridViewTextBoxColumn,
            this.nEXTPRICEDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.pMODIFYBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(0, 40);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.RowTemplate.Height = 23;
            this.dataGridView1.Size = new System.Drawing.Size(503, 430);
            this.dataGridView1.TabIndex = 16;
            // 
            // dataSet1
            // 
            this.dataSet1.DataSetName = "DataSet1";
            this.dataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // pMODIFYBindingSource
            // 
            this.pMODIFYBindingSource.DataMember = "P_MODIFY";
            this.pMODIFYBindingSource.DataSource = this.dataSet1;
            // 
            // p_MODIFYTableAdapter
            // 
            this.p_MODIFYTableAdapter.ClearBeforeFill = true;
            // 
            // pKINDDataGridViewTextBoxColumn
            // 
            this.pKINDDataGridViewTextBoxColumn.DataPropertyName = "P_KIND";
            this.pKINDDataGridViewTextBoxColumn.HeaderText = "상품 종류";
            this.pKINDDataGridViewTextBoxColumn.Name = "pKINDDataGridViewTextBoxColumn";
            // 
            // pNODataGridViewTextBoxColumn
            // 
            this.pNODataGridViewTextBoxColumn.DataPropertyName = "P_NO";
            this.pNODataGridViewTextBoxColumn.HeaderText = "상품 번호";
            this.pNODataGridViewTextBoxColumn.Name = "pNODataGridViewTextBoxColumn";
            // 
            // pNAMEDataGridViewTextBoxColumn
            // 
            this.pNAMEDataGridViewTextBoxColumn.DataPropertyName = "P_NAME";
            this.pNAMEDataGridViewTextBoxColumn.HeaderText = "상품 이름";
            this.pNAMEDataGridViewTextBoxColumn.Name = "pNAMEDataGridViewTextBoxColumn";
            // 
            // pREPRICEDataGridViewTextBoxColumn
            // 
            this.pREPRICEDataGridViewTextBoxColumn.DataPropertyName = "PRE_PRICE";
            this.pREPRICEDataGridViewTextBoxColumn.HeaderText = "기존 가격";
            this.pREPRICEDataGridViewTextBoxColumn.Name = "pREPRICEDataGridViewTextBoxColumn";
            // 
            // nEXTPRICEDataGridViewTextBoxColumn
            // 
            this.nEXTPRICEDataGridViewTextBoxColumn.DataPropertyName = "NEXT_PRICE";
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.LightPink;
            this.nEXTPRICEDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle2;
            this.nEXTPRICEDataGridViewTextBoxColumn.HeaderText = "할인 가격";
            this.nEXTPRICEDataGridViewTextBoxColumn.Name = "nEXTPRICEDataGridViewTextBoxColumn";
            // 
            // chart1
            // 
            chartArea2.AxisX.MajorGrid.LineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.NotSet;
            chartArea2.Name = "ChartArea1";
            this.chart1.ChartAreas.Add(chartArea2);
            this.chart1.DataSource = this.pTOP10SELLBindingSource;
            legend2.Docking = System.Windows.Forms.DataVisualization.Charting.Docking.Top;
            legend2.Name = "Legend1";
            this.chart1.Legends.Add(legend2);
            this.chart1.Location = new System.Drawing.Point(509, 40);
            this.chart1.Name = "chart1";
            series2.ChartArea = "ChartArea1";
            series2.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.StackedBar;
            series2.Legend = "Legend1";
            series2.Name = "판매량";
            series2.XValueMember = "P_NAME";
            series2.YValueMembers = "PCOUNT";
            this.chart1.Series.Add(series2);
            this.chart1.Size = new System.Drawing.Size(279, 430);
            this.chart1.TabIndex = 17;
            this.chart1.Text = "chart1";
            // 
            // pTOP10SELLBindingSource
            // 
            this.pTOP10SELLBindingSource.DataMember = "P_TOP_10_SELL";
            this.pTOP10SELLBindingSource.DataSource = this.dataSet1;
            // 
            // p_TOP_10_SELLTableAdapter
            // 
            this.p_TOP_10_SELLTableAdapter.ClearBeforeFill = true;
            // 
            // C_PopularProduct
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(800, 470);
            this.Controls.Add(this.chart1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.labelName);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "C_PopularProduct";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "C_PopularProduct";
            this.Load += new System.EventHandler(this.C_PopularProduct_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pMODIFYBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pTOP10SELLBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelName;
        private System.Windows.Forms.DataGridView dataGridView1;
        private DataSet1 dataSet1;
        private System.Windows.Forms.BindingSource pMODIFYBindingSource;
        private DataSet1TableAdapters.P_MODIFYTableAdapter p_MODIFYTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn pKINDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pNODataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pNAMEDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pREPRICEDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nEXTPRICEDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart1;
        private System.Windows.Forms.BindingSource pTOP10SELLBindingSource;
        private DataSet1TableAdapters.P_TOP_10_SELLTableAdapter p_TOP_10_SELLTableAdapter;
    }
}