﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 기말_프로젝트_시작
{
    public partial class S_BuyingRequest : Form
    {
        string USER;

        int count = 0;

        public S_BuyingRequest(string C_NAME)
        {
            InitializeComponent();
            USER = C_NAME;
        }

        private void S_BuyingRequest_Load(object sender, EventArgs e)
        {
            // TODO: 이 코드는 데이터를 'dataSet1.BUYING' 테이블에 로드합니다. 필요 시 이 코드를 이동하거나 제거할 수 있습니다.
            this.bUYINGTableAdapter.Fill(this.dataSet1.BUYING);
            bUYINGBindingSource.Filter = "S_NO = '" + USER.Replace("'", "''") + "'"; // 판매자만 보이게 하기.
            productTableAdapter1.Fill(this.dataSet1.PRODUCT);
            customerTableAdapter1.Fill(this.dataSet1.CUSTOMER);
        }

        private void button1_Click(object sender, EventArgs e) // 업데이트 버튼
        {
            try
            {
                this.bUYINGBindingSource.EndEdit();
                int ret = this.bUYINGTableAdapter.Update(this.dataSet1.BUYING);
                if (ret > 0)
                    MessageBox.Show("업데이트 완료!");
            }
            catch
            {
                MessageBox.Show("업데이트가 실패했습니다.");
            }
        }

        private void button2_Click(object sender, EventArgs e) // 구매 요청 승인
        {
            // 1. 식별 번호
            if(textBox1.Text == "")
            {
                MessageBox.Show("식별 번호를 입력해주세요");
                return;
            }

            // 2. 고객 번호
            if (textBox2.Text == "")
            {
                MessageBox.Show("고객 이름을 입력해주세요");
                return;
            }

            // 3. 상품 번호
            if (textBox3.Text == "")
            {
                MessageBox.Show("상품 번호를 입력해주세요");
                return;
            }

            // 1개씩 장바구니 -> BUYING 테이블로 이동
            try
            {
                // 1. BUYING -> IS_OK == OK로 바꾸기
                foreach (DataRow mydataRow in dataSet1.Tables["BUYING"].Rows)
                {
                    if (mydataRow["S_NO"].ToString() == USER &&
                        
                        mydataRow["C_NO"].ToString() == textBox2.Text &&
                        mydataRow["P_NO"].ToString() == textBox3.Text &&
                        mydataRow["B_OK"].ToString() == "NOT") // 판매자 + 구매자 + 상품 번호 + B_OK : 같아야함
                    {
                        mydataRow["B_OK"] = "OK"; // B_OK = OK로 바꾸기
                        count = Convert.ToInt32(mydataRow["B_COUNT"].ToString()); // 구매 횟수 저장하기.
                    }
                }
                bUYINGTableAdapter.Update(this.dataSet1.BUYING); // BUYING 업데이트

                // 2. BUYING -> PRODUCT == 개수 올리기
                // 중복은 CART 테이블의 B_COUNT만큼 증가
                foreach (DataRow mydataRow in dataSet1.Tables["PRODUCT"].Rows)
                {
                    if (mydataRow["C_NO"].ToString() == USER && mydataRow["P_NO"].ToString() == textBox3.Text) // 물품 판매 횟수 올리기
                    {
                        int a = Convert.ToInt32(mydataRow["P_SELL"].ToString()) + count; // 기존 물품 개수 + 구매한 물품 개수
                        mydataRow["P_SELL"] = a.ToString();
                    }

                    // 품절 여부 파악하기
                    if (Convert.ToInt32(mydataRow["P_SELL"].ToString()) == Convert.ToInt32(mydataRow["P_COUNT"]))
                    {
                        mydataRow["P_SOLDOUT"] = "0";
                    }
                }
                productTableAdapter1.Update(this.dataSet1.PRODUCT); // PRODUCT 업데이트 


                count = 0;
                // 3. CUSTOMER -> C_BUYCNT 개수 늘리기
                foreach (DataRow mydataRow in dataSet1.Tables["CUSTOMER"].Rows)
                {
                    if (mydataRow["C_NO"].ToString() == textBox2.Text) // 사용자 환불 횟수 늘리기
                    {
                        count = Convert.ToInt32(mydataRow["C_BUYCNT"].ToString()) + 1;
                        mydataRow["C_BUYCNT"] = count.ToString();
                    }

                }
                customerTableAdapter1.Update(this.dataSet1.CUSTOMER); // CUSTOMER 업데이트

                
                // 초기화
                textBox1.Text = "";
                textBox2.Text = "";
                textBox3.Text = "";
                count = 0;

                MessageBox.Show("구매 요청 승인 완료!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("업데이트 중 오류가 발생했습니다: " + ex.Message);
            }
        }
    }
}
