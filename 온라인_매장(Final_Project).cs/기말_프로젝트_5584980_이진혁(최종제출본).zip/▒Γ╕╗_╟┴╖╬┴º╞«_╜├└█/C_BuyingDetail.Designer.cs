﻿
namespace 기말_프로젝트_시작
{
    partial class C_BuyingDetail
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.labelName = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.bOKDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cARTNODataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cNODataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pKINDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pNODataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.P_NAME = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sNODataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bDATEDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bPRICEDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bCOUNTDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bUYINGBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.dataSet1 = new 기말_프로젝트_시작.DataSet1();
            this.bUYINGTableAdapter = new 기말_프로젝트_시작.DataSet1TableAdapters.BUYINGTableAdapter();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.bUYINGBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.bUYINGBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.refundTableAdapter1 = new 기말_프로젝트_시작.DataSet1TableAdapters.REFUNDTableAdapter();
            this.productTableAdapter1 = new 기말_프로젝트_시작.DataSet1TableAdapters.PRODUCTTableAdapter();
            this.cartTableAdapter1 = new 기말_프로젝트_시작.DataSet1TableAdapters.CARTTableAdapter();
            this.bOKDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cARTNODataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cNODataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pKINDDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pNODataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sNODataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bDATEDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bPRICEDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bCOUNTDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bUYINGBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bUYINGBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bUYINGBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // labelName
            // 
            this.labelName.AutoSize = true;
            this.labelName.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.labelName.ForeColor = System.Drawing.Color.DarkSlateBlue;
            this.labelName.Location = new System.Drawing.Point(350, 10);
            this.labelName.Name = "labelName";
            this.labelName.Size = new System.Drawing.Size(80, 21);
            this.labelName.TabIndex = 14;
            this.labelName.Text = "구매 내역";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.AntiqueWhite;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.bOKDataGridViewTextBoxColumn,
            this.cARTNODataGridViewTextBoxColumn,
            this.cNODataGridViewTextBoxColumn,
            this.pKINDDataGridViewTextBoxColumn,
            this.pNODataGridViewTextBoxColumn,
            this.P_NAME,
            this.sNODataGridViewTextBoxColumn,
            this.bDATEDataGridViewTextBoxColumn,
            this.bPRICEDataGridViewTextBoxColumn,
            this.bCOUNTDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.bUYINGBindingSource1;
            this.dataGridView1.Location = new System.Drawing.Point(-2, 0);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 23;
            this.dataGridView1.Size = new System.Drawing.Size(796, 404);
            this.dataGridView1.TabIndex = 15;
            // 
            // bOKDataGridViewTextBoxColumn
            // 
            this.bOKDataGridViewTextBoxColumn.DataPropertyName = "B_OK";
            this.bOKDataGridViewTextBoxColumn.HeaderText = "승인 여부";
            this.bOKDataGridViewTextBoxColumn.Name = "bOKDataGridViewTextBoxColumn";
            // 
            // cARTNODataGridViewTextBoxColumn
            // 
            this.cARTNODataGridViewTextBoxColumn.DataPropertyName = "CART_NO";
            this.cARTNODataGridViewTextBoxColumn.HeaderText = "식별 번호";
            this.cARTNODataGridViewTextBoxColumn.Name = "cARTNODataGridViewTextBoxColumn";
            // 
            // cNODataGridViewTextBoxColumn
            // 
            this.cNODataGridViewTextBoxColumn.DataPropertyName = "C_NO";
            this.cNODataGridViewTextBoxColumn.HeaderText = "구매자";
            this.cNODataGridViewTextBoxColumn.Name = "cNODataGridViewTextBoxColumn";
            // 
            // pKINDDataGridViewTextBoxColumn
            // 
            this.pKINDDataGridViewTextBoxColumn.DataPropertyName = "P_KIND";
            this.pKINDDataGridViewTextBoxColumn.HeaderText = "상품 종류";
            this.pKINDDataGridViewTextBoxColumn.Name = "pKINDDataGridViewTextBoxColumn";
            // 
            // pNODataGridViewTextBoxColumn
            // 
            this.pNODataGridViewTextBoxColumn.DataPropertyName = "P_NO";
            this.pNODataGridViewTextBoxColumn.HeaderText = "상품 번호";
            this.pNODataGridViewTextBoxColumn.Name = "pNODataGridViewTextBoxColumn";
            // 
            // P_NAME
            // 
            this.P_NAME.DataPropertyName = "P_NAME";
            this.P_NAME.HeaderText = "상품 이름";
            this.P_NAME.Name = "P_NAME";
            // 
            // sNODataGridViewTextBoxColumn
            // 
            this.sNODataGridViewTextBoxColumn.DataPropertyName = "S_NO";
            this.sNODataGridViewTextBoxColumn.HeaderText = "판매자";
            this.sNODataGridViewTextBoxColumn.Name = "sNODataGridViewTextBoxColumn";
            // 
            // bDATEDataGridViewTextBoxColumn
            // 
            this.bDATEDataGridViewTextBoxColumn.DataPropertyName = "B_DATE";
            this.bDATEDataGridViewTextBoxColumn.HeaderText = "구매 날짜";
            this.bDATEDataGridViewTextBoxColumn.Name = "bDATEDataGridViewTextBoxColumn";
            // 
            // bPRICEDataGridViewTextBoxColumn
            // 
            this.bPRICEDataGridViewTextBoxColumn.DataPropertyName = "B_PRICE";
            this.bPRICEDataGridViewTextBoxColumn.HeaderText = "구매 가격";
            this.bPRICEDataGridViewTextBoxColumn.Name = "bPRICEDataGridViewTextBoxColumn";
            // 
            // bCOUNTDataGridViewTextBoxColumn
            // 
            this.bCOUNTDataGridViewTextBoxColumn.DataPropertyName = "B_COUNT";
            this.bCOUNTDataGridViewTextBoxColumn.HeaderText = "개수";
            this.bCOUNTDataGridViewTextBoxColumn.Name = "bCOUNTDataGridViewTextBoxColumn";
            // 
            // bUYINGBindingSource1
            // 
            this.bUYINGBindingSource1.DataMember = "BUYING";
            this.bUYINGBindingSource1.DataSource = this.dataSet1;
            // 
            // dataSet1
            // 
            this.dataSet1.DataSetName = "DataSet1";
            this.dataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // bUYINGTableAdapter
            // 
            this.bUYINGTableAdapter.ClearBeforeFill = true;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Location = new System.Drawing.Point(0, 40);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(800, 430);
            this.tabControl1.TabIndex = 16;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.dataGridView1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(792, 404);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "구매 내역";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.richTextBox1);
            this.tabPage5.Controls.Add(this.label1);
            this.tabPage5.Controls.Add(this.checkBox1);
            this.tabPage5.Controls.Add(this.textBox4);
            this.tabPage5.Controls.Add(this.textBox6);
            this.tabPage5.Controls.Add(this.textBox7);
            this.tabPage5.Controls.Add(this.listBox1);
            this.tabPage5.Controls.Add(this.textBox5);
            this.tabPage5.Controls.Add(this.label4);
            this.tabPage5.Controls.Add(this.textBox1);
            this.tabPage5.Controls.Add(this.button2);
            this.tabPage5.Controls.Add(this.dataGridView2);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Size = new System.Drawing.Size(792, 404);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "환불하기";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // richTextBox1
            // 
            this.richTextBox1.Font = new System.Drawing.Font("맑은 고딕", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.richTextBox1.ForeColor = System.Drawing.Color.DarkSlateBlue;
            this.richTextBox1.Location = new System.Drawing.Point(561, 154);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(223, 65);
            this.richTextBox1.TabIndex = 71;
            this.richTextBox1.Text = "";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label1.Font = new System.Drawing.Font("맑은 고딕", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label1.ForeColor = System.Drawing.Color.DarkSlateBlue;
            this.label1.Location = new System.Drawing.Point(561, 123);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(97, 27);
            this.label1.TabIndex = 70;
            this.label1.Text = "환불 사유";
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Font = new System.Drawing.Font("맑은 고딕", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.checkBox1.Location = new System.Drawing.Point(620, 295);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(95, 21);
            this.checkBox1.TabIndex = 68;
            this.checkBox1.Text = "동의합니다.";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // textBox4
            // 
            this.textBox4.BackColor = System.Drawing.Color.White;
            this.textBox4.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox4.ForeColor = System.Drawing.Color.Red;
            this.textBox4.Location = new System.Drawing.Point(570, 272);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(177, 14);
            this.textBox4.TabIndex = 66;
            this.textBox4.Text = "* 위 내용에 동의하시겠습니까?";
            // 
            // textBox6
            // 
            this.textBox6.BackColor = System.Drawing.Color.White;
            this.textBox6.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox6.ForeColor = System.Drawing.Color.Red;
            this.textBox6.Location = new System.Drawing.Point(578, 252);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(202, 14);
            this.textBox6.TabIndex = 65;
            this.textBox6.Text = "서비스 이용 제한을 받을 수 있습니다. ";
            // 
            // textBox7
            // 
            this.textBox7.BackColor = System.Drawing.Color.White;
            this.textBox7.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox7.ForeColor = System.Drawing.Color.Red;
            this.textBox7.Location = new System.Drawing.Point(570, 232);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(210, 14);
            this.textBox7.TabIndex = 64;
            this.textBox7.Text = "* 구매 후 악의적인 사유로 인한 환불은 제재를 가할 수 있습니다. ";
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 12;
            this.listBox1.Location = new System.Drawing.Point(561, 225);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(223, 64);
            this.listBox1.TabIndex = 67;
            // 
            // textBox5
            // 
            this.textBox5.BackColor = System.Drawing.Color.White;
            this.textBox5.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox5.ForeColor = System.Drawing.Color.Red;
            this.textBox5.Location = new System.Drawing.Point(561, 14);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(97, 14);
            this.textBox5.TabIndex = 63;
            this.textBox5.Text = "* 환불하기 방법";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label4.Font = new System.Drawing.Font("맑은 고딕", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label4.ForeColor = System.Drawing.Color.DarkSlateBlue;
            this.label4.Location = new System.Drawing.Point(561, 90);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(97, 27);
            this.label4.TabIndex = 58;
            this.label4.Text = "식별 번호";
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("맑은 고딕", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.textBox1.ForeColor = System.Drawing.Color.DarkSlateBlue;
            this.textBox1.Location = new System.Drawing.Point(664, 90);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(120, 27);
            this.textBox1.TabIndex = 57;
            // 
            // button2
            // 
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button2.ForeColor = System.Drawing.Color.DarkSlateBlue;
            this.button2.Location = new System.Drawing.Point(561, 323);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(223, 41);
            this.button2.TabIndex = 56;
            this.button2.Text = "환불 요청하기";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // dataGridView2
            // 
            this.dataGridView2.AutoGenerateColumns = false;
            this.dataGridView2.BackgroundColor = System.Drawing.Color.AntiqueWhite;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.bOKDataGridViewTextBoxColumn1,
            this.cARTNODataGridViewTextBoxColumn1,
            this.cNODataGridViewTextBoxColumn1,
            this.pKINDDataGridViewTextBoxColumn1,
            this.pNODataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn1,
            this.sNODataGridViewTextBoxColumn1,
            this.bDATEDataGridViewTextBoxColumn1,
            this.bPRICEDataGridViewTextBoxColumn1,
            this.bCOUNTDataGridViewTextBoxColumn1});
            this.dataGridView2.DataSource = this.bUYINGBindingSource2;
            this.dataGridView2.Location = new System.Drawing.Point(-2, 0);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowTemplate.Height = 23;
            this.dataGridView2.Size = new System.Drawing.Size(543, 404);
            this.dataGridView2.TabIndex = 16;
            // 
            // bUYINGBindingSource2
            // 
            this.bUYINGBindingSource2.DataMember = "BUYING";
            this.bUYINGBindingSource2.DataSource = this.dataSet1;
            // 
            // bUYINGBindingSource
            // 
            this.bUYINGBindingSource.DataMember = "BUYING";
            // 
            // refundTableAdapter1
            // 
            this.refundTableAdapter1.ClearBeforeFill = true;
            // 
            // productTableAdapter1
            // 
            this.productTableAdapter1.ClearBeforeFill = true;
            // 
            // cartTableAdapter1
            // 
            this.cartTableAdapter1.ClearBeforeFill = true;
            // 
            // bOKDataGridViewTextBoxColumn1
            // 
            this.bOKDataGridViewTextBoxColumn1.DataPropertyName = "B_OK";
            this.bOKDataGridViewTextBoxColumn1.HeaderText = "승인 여부";
            this.bOKDataGridViewTextBoxColumn1.Name = "bOKDataGridViewTextBoxColumn1";
            // 
            // cARTNODataGridViewTextBoxColumn1
            // 
            this.cARTNODataGridViewTextBoxColumn1.DataPropertyName = "CART_NO";
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.LightPink;
            this.cARTNODataGridViewTextBoxColumn1.DefaultCellStyle = dataGridViewCellStyle1;
            this.cARTNODataGridViewTextBoxColumn1.HeaderText = "식별 번호";
            this.cARTNODataGridViewTextBoxColumn1.Name = "cARTNODataGridViewTextBoxColumn1";
            // 
            // cNODataGridViewTextBoxColumn1
            // 
            this.cNODataGridViewTextBoxColumn1.DataPropertyName = "C_NO";
            this.cNODataGridViewTextBoxColumn1.HeaderText = "구매자";
            this.cNODataGridViewTextBoxColumn1.Name = "cNODataGridViewTextBoxColumn1";
            // 
            // pKINDDataGridViewTextBoxColumn1
            // 
            this.pKINDDataGridViewTextBoxColumn1.DataPropertyName = "P_KIND";
            this.pKINDDataGridViewTextBoxColumn1.HeaderText = "상품 종류";
            this.pKINDDataGridViewTextBoxColumn1.Name = "pKINDDataGridViewTextBoxColumn1";
            // 
            // pNODataGridViewTextBoxColumn1
            // 
            this.pNODataGridViewTextBoxColumn1.DataPropertyName = "P_NO";
            this.pNODataGridViewTextBoxColumn1.HeaderText = "상품 번호";
            this.pNODataGridViewTextBoxColumn1.Name = "pNODataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "P_NAME";
            this.dataGridViewTextBoxColumn1.HeaderText = "상품 이름";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // sNODataGridViewTextBoxColumn1
            // 
            this.sNODataGridViewTextBoxColumn1.DataPropertyName = "S_NO";
            this.sNODataGridViewTextBoxColumn1.HeaderText = "판매자";
            this.sNODataGridViewTextBoxColumn1.Name = "sNODataGridViewTextBoxColumn1";
            // 
            // bDATEDataGridViewTextBoxColumn1
            // 
            this.bDATEDataGridViewTextBoxColumn1.DataPropertyName = "B_DATE";
            this.bDATEDataGridViewTextBoxColumn1.HeaderText = "구매 날짜";
            this.bDATEDataGridViewTextBoxColumn1.Name = "bDATEDataGridViewTextBoxColumn1";
            // 
            // bPRICEDataGridViewTextBoxColumn1
            // 
            this.bPRICEDataGridViewTextBoxColumn1.DataPropertyName = "B_PRICE";
            this.bPRICEDataGridViewTextBoxColumn1.HeaderText = "구매 가격";
            this.bPRICEDataGridViewTextBoxColumn1.Name = "bPRICEDataGridViewTextBoxColumn1";
            // 
            // bCOUNTDataGridViewTextBoxColumn1
            // 
            this.bCOUNTDataGridViewTextBoxColumn1.DataPropertyName = "B_COUNT";
            this.bCOUNTDataGridViewTextBoxColumn1.HeaderText = "개수";
            this.bCOUNTDataGridViewTextBoxColumn1.Name = "bCOUNTDataGridViewTextBoxColumn1";
            // 
            // C_BuyingDetail
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(800, 470);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.labelName);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "C_BuyingDetail";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "C_BuyingDetail";
            this.Load += new System.EventHandler(this.C_BuyingDetail_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bUYINGBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bUYINGBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bUYINGBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelName;
        private System.Windows.Forms.DataGridView dataGridView1;
        private DataSet1 dataSet1;
        private System.Windows.Forms.BindingSource bUYINGBindingSource1;
        private DataSet1TableAdapters.BUYINGTableAdapter bUYINGTableAdapter;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.BindingSource bUYINGBindingSource;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.BindingSource bUYINGBindingSource2;
        private DataSet1TableAdapters.REFUNDTableAdapter refundTableAdapter1;
        private DataSet1TableAdapters.PRODUCTTableAdapter productTableAdapter1;
        private DataSet1TableAdapters.CARTTableAdapter cartTableAdapter1;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.DataGridViewTextBoxColumn bOKDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cARTNODataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cNODataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pKINDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pNODataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn P_NAME;
        private System.Windows.Forms.DataGridViewTextBoxColumn sNODataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn bDATEDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn bPRICEDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn bCOUNTDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn bOKDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn cARTNODataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn cNODataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn pKINDDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn pNODataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn sNODataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn bDATEDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn bPRICEDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn bCOUNTDataGridViewTextBoxColumn1;
    }
}