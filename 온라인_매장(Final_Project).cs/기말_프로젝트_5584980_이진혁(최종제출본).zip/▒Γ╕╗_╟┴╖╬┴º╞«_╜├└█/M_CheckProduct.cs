﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 기말_프로젝트_시작
{
    public partial class M_CheckProduct : Form
    {
        public M_CheckProduct()
        {
            InitializeComponent();
        }

        private void M_CheckProduct_Load(object sender, EventArgs e)
        {
            // TODO: 이 코드는 데이터를 'dataSet1.PRODUCT' 테이블에 로드합니다. 필요 시 이 코드를 이동하거나 제거할 수 있습니다.
            this.pRODUCTTableAdapter.Fill(this.dataSet1.PRODUCT);
        }

        private void button4_Click(object sender, EventArgs e) // 상품 종류 검색
        {
            if (pRODUCTBindingSource1.Filter != null)
            {
                textBox1.Text = "";
                pRODUCTBindingSource1.RemoveFilter();
                button4.Text = "종류 검색";
            }
            else
            {
                pRODUCTBindingSource1.Filter = "P_KIND LIKE '%" + textBox1.Text + "%'";
                button4.Text = "필터 해제";
            }
        }

        private void button3_Click(object sender, EventArgs e) // 상품 이름 검색
        {
            if (pRODUCTBindingSource1.Filter != null)
            {
                textBox1.Text = "";
                pRODUCTBindingSource1.RemoveFilter();
                button3.Text = "이름 검색";
            }
            else
            {
                pRODUCTBindingSource1.Filter = "P_NAME LIKE '%" + textBox1.Text + "%'";
                button3.Text = "필터 해제";
            }
        }

        private void button2_Click(object sender, EventArgs e) // 로그아웃
        {
            MessageBox.Show("로그아웃 되었습니다.");
            Application.Exit(); // 모든 화면 닫기

            /*
            LoginForm showform = new LoginForm();
            this.Visible = false;
            showform.Show();
            */
        }

        private void labelName_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView1_CellContentClick_2(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e) // 업데이트
        {
            try
            {
                this.pRODUCTBindingSource.EndEdit();
                int ret = this.pRODUCTTableAdapter.Update(this.dataSet1.PRODUCT);
                if (ret > 0)
                    MessageBox.Show("업데이트 완료!");
            }
            catch
            {
                MessageBox.Show("업데이트가 실패했습니다.");
            }
        }

        private void pRODUCTBindingSource_CurrentChanged(object sender, EventArgs e)
        {

        }
    }
}
