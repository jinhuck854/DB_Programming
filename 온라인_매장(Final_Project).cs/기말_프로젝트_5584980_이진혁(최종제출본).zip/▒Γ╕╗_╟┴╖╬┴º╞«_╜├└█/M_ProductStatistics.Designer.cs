﻿
namespace 기말_프로젝트_시작
{
    partial class M_ProductStatistics
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Title title1 = new System.Windows.Forms.DataVisualization.Charting.Title();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea2 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend2 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Title title2 = new System.Windows.Forms.DataVisualization.Charting.Title();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea3 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend3 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series3 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Title title3 = new System.Windows.Forms.DataVisualization.Charting.Title();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea4 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend4 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series4 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Title title4 = new System.Windows.Forms.DataVisualization.Charting.Title();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea5 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Series series5 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Title title5 = new System.Windows.Forms.DataVisualization.Charting.Title();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea6 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend5 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series6 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Title title6 = new System.Windows.Forms.DataVisualization.Charting.Title();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea7 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend6 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series7 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Title title7 = new System.Windows.Forms.DataVisualization.Charting.Title();
            this.labelName = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.pSELLKINDBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataSet1 = new 기말_프로젝트_시작.DataSet1();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.chart2 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.dAILYSALESBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.chart6 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.wEEKLYSALESBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.chart4 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.dAYOFWEEKSALESBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.button3 = new System.Windows.Forms.Button();
            this.dateTimePicker3 = new System.Windows.Forms.DateTimePicker();
            this.label2 = new System.Windows.Forms.Label();
            this.dateTimePicker4 = new System.Windows.Forms.DateTimePicker();
            this.chart5 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.dAILYSALESBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.dataSet11 = new 기말_프로젝트_시작.DataSet1();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.chart3 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.pREFUNDBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.chart7 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.button1 = new System.Windows.Forms.Button();
            this.bUYINGBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.pRODUCTBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.pRODUCTTableAdapter = new 기말_프로젝트_시작.DataSet1TableAdapters.PRODUCTTableAdapter();
            this.p_SELL_KINDTableAdapter = new 기말_프로젝트_시작.DataSet1TableAdapters.P_SELL_KINDTableAdapter();
            this.dAILYSALESTableAdapter = new 기말_프로젝트_시작.DataSet1TableAdapters.DAILYSALESTableAdapter();
            this.dAYOFWEEKSALESTableAdapter = new 기말_프로젝트_시작.DataSet1TableAdapters.DAYOFWEEKSALESTableAdapter();
            this.wEEKLYSALESTableAdapter = new 기말_프로젝트_시작.DataSet1TableAdapters.WEEKLYSALESTableAdapter();
            this.p_REFUNDTableAdapter = new 기말_프로젝트_시작.DataSet1TableAdapters.P_REFUNDTableAdapter();
            this.pREVIEWBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.p_REVIEWTableAdapter = new 기말_프로젝트_시작.DataSet1TableAdapters.P_REVIEWTableAdapter();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pSELLKINDBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dAILYSALESBindingSource)).BeginInit();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.wEEKLYSALESBindingSource)).BeginInit();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dAYOFWEEKSALESBindingSource)).BeginInit();
            this.tabPage6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dAILYSALESBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet11)).BeginInit();
            this.tabPage5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pREFUNDBindingSource)).BeginInit();
            this.tabPage7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bUYINGBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pRODUCTBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pREVIEWBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // labelName
            // 
            this.labelName.AutoSize = true;
            this.labelName.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.labelName.ForeColor = System.Drawing.Color.DarkSlateBlue;
            this.labelName.Location = new System.Drawing.Point(350, 10);
            this.labelName.Name = "labelName";
            this.labelName.Size = new System.Drawing.Size(134, 21);
            this.labelName.TabIndex = 2;
            this.labelName.Text = "상품 판매량 통계";
            this.labelName.Click += new System.EventHandler(this.labelName_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage6);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Controls.Add(this.tabPage7);
            this.tabControl1.Location = new System.Drawing.Point(0, 40);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(800, 430);
            this.tabControl1.TabIndex = 3;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.chart1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(792, 404);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "종류별 판매량";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // chart1
            // 
            chartArea1.AxisX.IntervalAutoMode = System.Windows.Forms.DataVisualization.Charting.IntervalAutoMode.VariableCount;
            chartArea1.AxisX.IsLabelAutoFit = false;
            chartArea1.AxisX.LabelStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            chartArea1.AxisX.LabelStyle.IsStaggered = true;
            chartArea1.AxisX.MajorGrid.Enabled = false;
            chartArea1.AxisX.TitleFont = new System.Drawing.Font("Microsoft Sans Serif", 3F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            chartArea1.Name = "ChartArea1";
            this.chart1.ChartAreas.Add(chartArea1);
            this.chart1.DataSource = this.pSELLKINDBindingSource;
            legend1.Docking = System.Windows.Forms.DataVisualization.Charting.Docking.Top;
            legend1.Name = "Legend1";
            this.chart1.Legends.Add(legend1);
            this.chart1.Location = new System.Drawing.Point(8, 7);
            this.chart1.Name = "chart1";
            series1.ChartArea = "ChartArea1";
            series1.Color = System.Drawing.Color.Red;
            series1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            series1.Legend = "Legend1";
            series1.Name = "판매량";
            series1.XValueMember = "P_KIND";
            series1.YValueMembers = "PCOUNT";
            this.chart1.Series.Add(series1);
            this.chart1.Size = new System.Drawing.Size(776, 390);
            this.chart1.TabIndex = 8;
            this.chart1.Text = "chart1";
            title1.Name = "Title1";
            title1.Text = "상품 종류별 판매량";
            this.chart1.Titles.Add(title1);
            this.chart1.Click += new System.EventHandler(this.chart1_Click_2);
            // 
            // pSELLKINDBindingSource
            // 
            this.pSELLKINDBindingSource.DataMember = "P_SELL_KIND";
            this.pSELLKINDBindingSource.DataSource = this.dataSet1;
            // 
            // dataSet1
            // 
            this.dataSet1.DataSetName = "DataSet1";
            this.dataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.chart2);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(792, 404);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "일별 판매액";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // chart2
            // 
            chartArea2.AxisX.MajorGrid.Enabled = false;
            chartArea2.AxisX.ScrollBar.LineColor = System.Drawing.Color.White;
            chartArea2.CursorX.LineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.Dash;
            chartArea2.Name = "ChartArea1";
            this.chart2.ChartAreas.Add(chartArea2);
            this.chart2.DataSource = this.dAILYSALESBindingSource;
            legend2.Docking = System.Windows.Forms.DataVisualization.Charting.Docking.Top;
            legend2.Name = "Legend1";
            this.chart2.Legends.Add(legend2);
            this.chart2.Location = new System.Drawing.Point(8, 7);
            this.chart2.Name = "chart2";
            series2.BorderWidth = 3;
            series2.ChartArea = "ChartArea1";
            series2.Color = System.Drawing.Color.Red;
            series2.Legend = "Legend1";
            series2.Name = "판매금액";
            series2.XValueMember = "SALEDATE";
            series2.YValueMembers = "TOTALSALES";
            this.chart2.Series.Add(series2);
            this.chart2.Size = new System.Drawing.Size(776, 390);
            this.chart2.TabIndex = 5;
            this.chart2.Text = "chart2";
            title2.Name = "Title1";
            title2.Text = "일별 판매액";
            this.chart2.Titles.Add(title2);
            this.chart2.Click += new System.EventHandler(this.chart2_Click_1);
            // 
            // dAILYSALESBindingSource
            // 
            this.dAILYSALESBindingSource.DataMember = "DAILYSALES";
            this.dAILYSALESBindingSource.DataSource = this.dataSet1;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.chart6);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(792, 404);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "주별 판매액";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // chart6
            // 
            chartArea3.AxisX.MajorGrid.Enabled = false;
            chartArea3.Name = "ChartArea1";
            this.chart6.ChartAreas.Add(chartArea3);
            this.chart6.DataSource = this.wEEKLYSALESBindingSource;
            legend3.Docking = System.Windows.Forms.DataVisualization.Charting.Docking.Top;
            legend3.Name = "Legend1";
            this.chart6.Legends.Add(legend3);
            this.chart6.Location = new System.Drawing.Point(8, 7);
            this.chart6.Name = "chart6";
            series3.ChartArea = "ChartArea1";
            series3.Color = System.Drawing.Color.Red;
            series3.Legend = "Legend1";
            series3.Name = "Series1";
            series3.XValueMember = "SALEWEEK";
            series3.YValueMembers = "TOTALSALES";
            this.chart6.Series.Add(series3);
            this.chart6.Size = new System.Drawing.Size(776, 390);
            this.chart6.TabIndex = 4;
            this.chart6.Text = "chart6";
            title3.Name = "Title1";
            title3.Text = "주별 판매액";
            this.chart6.Titles.Add(title3);
            // 
            // wEEKLYSALESBindingSource
            // 
            this.wEEKLYSALESBindingSource.DataMember = "WEEKLYSALES";
            this.wEEKLYSALESBindingSource.DataSource = this.dataSet1;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.chart4);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(792, 404);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "요일별 판매액";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // chart4
            // 
            chartArea4.AxisX.IntervalAutoMode = System.Windows.Forms.DataVisualization.Charting.IntervalAutoMode.VariableCount;
            chartArea4.AxisX.IsLabelAutoFit = false;
            chartArea4.AxisX.LabelStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            chartArea4.AxisX.LabelStyle.IsStaggered = true;
            chartArea4.AxisX.MajorGrid.Enabled = false;
            chartArea4.AxisX.TitleFont = new System.Drawing.Font("Microsoft Sans Serif", 3F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            chartArea4.Name = "ChartArea1";
            this.chart4.ChartAreas.Add(chartArea4);
            this.chart4.DataSource = this.dAYOFWEEKSALESBindingSource;
            legend4.Docking = System.Windows.Forms.DataVisualization.Charting.Docking.Top;
            legend4.Name = "Legend1";
            this.chart4.Legends.Add(legend4);
            this.chart4.Location = new System.Drawing.Point(8, 7);
            this.chart4.Name = "chart4";
            series4.ChartArea = "ChartArea1";
            series4.Color = System.Drawing.Color.Red;
            series4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            series4.Legend = "Legend1";
            series4.Name = "Series1";
            series4.XValueMember = "SALEWEEK";
            series4.YValueMembers = "TOTALSALES";
            this.chart4.Series.Add(series4);
            this.chart4.Size = new System.Drawing.Size(776, 390);
            this.chart4.TabIndex = 1;
            this.chart4.Text = "chart4";
            title4.Name = "Title1";
            title4.Text = "요일별 판매액";
            this.chart4.Titles.Add(title4);
            // 
            // dAYOFWEEKSALESBindingSource
            // 
            this.dAYOFWEEKSALESBindingSource.DataMember = "DAYOFWEEKSALES";
            this.dAYOFWEEKSALESBindingSource.DataSource = this.dataSet1;
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.button3);
            this.tabPage6.Controls.Add(this.dateTimePicker3);
            this.tabPage6.Controls.Add(this.label2);
            this.tabPage6.Controls.Add(this.dateTimePicker4);
            this.tabPage6.Controls.Add(this.chart5);
            this.tabPage6.Location = new System.Drawing.Point(4, 22);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage6.Size = new System.Drawing.Size(792, 404);
            this.tabPage6.TabIndex = 5;
            this.tabPage6.Text = "날짜 선택별 판매액";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("맑은 고딕", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button3.Location = new System.Drawing.Point(620, 30);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 18;
            this.button3.Text = "선택하기";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // dateTimePicker3
            // 
            this.dateTimePicker3.Location = new System.Drawing.Point(146, 30);
            this.dateTimePicker3.Name = "dateTimePicker3";
            this.dateTimePicker3.Size = new System.Drawing.Size(200, 21);
            this.dateTimePicker3.TabIndex = 16;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(368, 35);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(14, 12);
            this.label2.TabIndex = 17;
            this.label2.Text = "~";
            // 
            // dateTimePicker4
            // 
            this.dateTimePicker4.Location = new System.Drawing.Point(402, 30);
            this.dateTimePicker4.Name = "dateTimePicker4";
            this.dateTimePicker4.Size = new System.Drawing.Size(200, 21);
            this.dateTimePicker4.TabIndex = 15;
            // 
            // chart5
            // 
            chartArea5.AxisX.MajorGrid.Enabled = false;
            chartArea5.AxisX.ScrollBar.LineColor = System.Drawing.Color.White;
            chartArea5.CursorX.LineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.Dash;
            chartArea5.Name = "ChartArea1";
            this.chart5.ChartAreas.Add(chartArea5);
            this.chart5.DataSource = this.dAILYSALESBindingSource1;
            this.chart5.Location = new System.Drawing.Point(8, 7);
            this.chart5.Name = "chart5";
            series5.ChartArea = "ChartArea1";
            series5.Color = System.Drawing.Color.Red;
            series5.Name = "Series1";
            this.chart5.Series.Add(series5);
            this.chart5.Size = new System.Drawing.Size(776, 390);
            this.chart5.TabIndex = 19;
            this.chart5.Text = "chart5";
            title5.Name = "Title1";
            this.chart5.Titles.Add(title5);
            // 
            // dAILYSALESBindingSource1
            // 
            this.dAILYSALESBindingSource1.DataMember = "DAILYSALES";
            this.dAILYSALESBindingSource1.DataSource = this.dataSet11;
            // 
            // dataSet11
            // 
            this.dataSet11.DataSetName = "DataSet1";
            this.dataSet11.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.chart3);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(792, 404);
            this.tabPage5.TabIndex = 6;
            this.tabPage5.Text = "환불 횟수";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // chart3
            // 
            chartArea6.AxisX.MajorGrid.Enabled = false;
            chartArea6.AxisX.ScrollBar.LineColor = System.Drawing.Color.White;
            chartArea6.CursorX.LineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.Dash;
            chartArea6.Name = "ChartArea1";
            this.chart3.ChartAreas.Add(chartArea6);
            this.chart3.DataSource = this.pREFUNDBindingSource;
            legend5.Docking = System.Windows.Forms.DataVisualization.Charting.Docking.Top;
            legend5.Name = "Legend1";
            this.chart3.Legends.Add(legend5);
            this.chart3.Location = new System.Drawing.Point(8, 7);
            this.chart3.Name = "chart3";
            series6.BorderWidth = 3;
            series6.ChartArea = "ChartArea1";
            series6.Color = System.Drawing.Color.Red;
            series6.Legend = "Legend1";
            series6.Name = "환불 횟수";
            series6.XValueMember = "P_KIND";
            series6.YValueMembers = "PCOUNT";
            this.chart3.Series.Add(series6);
            this.chart3.Size = new System.Drawing.Size(776, 390);
            this.chart3.TabIndex = 6;
            this.chart3.Text = "chart3";
            title6.Name = "Title1";
            title6.Text = "환불 많은 순";
            this.chart3.Titles.Add(title6);
            // 
            // pREFUNDBindingSource
            // 
            this.pREFUNDBindingSource.DataMember = "P_REFUND";
            this.pREFUNDBindingSource.DataSource = this.dataSet1;
            // 
            // tabPage7
            // 
            this.tabPage7.Controls.Add(this.chart7);
            this.tabPage7.Location = new System.Drawing.Point(4, 22);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage7.Size = new System.Drawing.Size(792, 404);
            this.tabPage7.TabIndex = 7;
            this.tabPage7.Text = "리뷰 횟수";
            this.tabPage7.UseVisualStyleBackColor = true;
            // 
            // chart7
            // 
            chartArea7.AxisX.MajorGrid.Enabled = false;
            chartArea7.AxisX.ScrollBar.LineColor = System.Drawing.Color.White;
            chartArea7.CursorX.LineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.Dash;
            chartArea7.Name = "ChartArea1";
            this.chart7.ChartAreas.Add(chartArea7);
            this.chart7.DataSource = this.pREVIEWBindingSource;
            legend6.Docking = System.Windows.Forms.DataVisualization.Charting.Docking.Top;
            legend6.Name = "Legend1";
            this.chart7.Legends.Add(legend6);
            this.chart7.Location = new System.Drawing.Point(8, 7);
            this.chart7.Name = "chart7";
            series7.BorderWidth = 3;
            series7.ChartArea = "ChartArea1";
            series7.Color = System.Drawing.Color.Red;
            series7.Legend = "Legend1";
            series7.Name = "환불 횟수";
            series7.XValueMember = "P_KIND";
            series7.YValueMembers = "PCOUNT";
            this.chart7.Series.Add(series7);
            this.chart7.Size = new System.Drawing.Size(776, 390);
            this.chart7.TabIndex = 7;
            this.chart7.Text = "chart7";
            title7.Name = "Title1";
            title7.Text = "환불 많은 순";
            this.chart7.Titles.Add(title7);
            // 
            // button1
            // 
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button1.Location = new System.Drawing.Point(713, 8);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 12;
            this.button1.Text = "새로고침";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // bUYINGBindingSource1
            // 
            this.bUYINGBindingSource1.DataMember = "BUYING";
            // 
            // pRODUCTBindingSource
            // 
            this.pRODUCTBindingSource.DataMember = "PRODUCT";
            this.pRODUCTBindingSource.DataSource = this.dataSet1;
            // 
            // pRODUCTTableAdapter
            // 
            this.pRODUCTTableAdapter.ClearBeforeFill = true;
            // 
            // p_SELL_KINDTableAdapter
            // 
            this.p_SELL_KINDTableAdapter.ClearBeforeFill = true;
            // 
            // dAILYSALESTableAdapter
            // 
            this.dAILYSALESTableAdapter.ClearBeforeFill = true;
            // 
            // dAYOFWEEKSALESTableAdapter
            // 
            this.dAYOFWEEKSALESTableAdapter.ClearBeforeFill = true;
            // 
            // wEEKLYSALESTableAdapter
            // 
            this.wEEKLYSALESTableAdapter.ClearBeforeFill = true;
            // 
            // p_REFUNDTableAdapter
            // 
            this.p_REFUNDTableAdapter.ClearBeforeFill = true;
            // 
            // pREVIEWBindingSource
            // 
            this.pREVIEWBindingSource.DataMember = "P_REVIEW";
            this.pREVIEWBindingSource.DataSource = this.dataSet1;
            // 
            // p_REVIEWTableAdapter
            // 
            this.p_REVIEWTableAdapter.ClearBeforeFill = true;
            // 
            // M_ProductStatistics
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(800, 470);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.labelName);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "M_ProductStatistics";
            this.Text = "M_ProductStatistics";
            this.Load += new System.EventHandler(this.M_ProductStatistics_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pSELLKINDBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1)).EndInit();
            this.tabPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.chart2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dAILYSALESBindingSource)).EndInit();
            this.tabPage3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.chart6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.wEEKLYSALESBindingSource)).EndInit();
            this.tabPage4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.chart4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dAYOFWEEKSALESBindingSource)).EndInit();
            this.tabPage6.ResumeLayout(false);
            this.tabPage6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dAILYSALESBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet11)).EndInit();
            this.tabPage5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.chart3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pREFUNDBindingSource)).EndInit();
            this.tabPage7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.chart7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bUYINGBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pRODUCTBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pREVIEWBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelName;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart4;
        private DataSet1 dataSet1;
        private System.Windows.Forms.BindingSource pSELLKINDBindingSource;
        private DataSet1TableAdapters.P_SELL_KINDTableAdapter p_SELL_KINDTableAdapter;
        private System.Windows.Forms.BindingSource pRODUCTBindingSource;
        private DataSet1TableAdapters.PRODUCTTableAdapter pRODUCTTableAdapter;
        private System.Windows.Forms.BindingSource dAILYSALESBindingSource;
        private DataSet1TableAdapters.DAILYSALESTableAdapter dAILYSALESTableAdapter;
        private System.Windows.Forms.BindingSource dAYOFWEEKSALESBindingSource;
        private DataSet1TableAdapters.DAYOFWEEKSALESTableAdapter dAYOFWEEKSALESTableAdapter;
        private System.Windows.Forms.BindingSource wEEKLYSALESBindingSource;
        private DataSet1TableAdapters.WEEKLYSALESTableAdapter wEEKLYSALESTableAdapter;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart6;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart2;
        private System.Windows.Forms.BindingSource bUYINGBindingSource1;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.DateTimePicker dateTimePicker3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DateTimePicker dateTimePicker4;
        private DataSet1 dataSet11;
        private System.Windows.Forms.BindingSource dAILYSALESBindingSource1;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart5;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart3;
        private System.Windows.Forms.BindingSource pREFUNDBindingSource;
        private DataSet1TableAdapters.P_REFUNDTableAdapter p_REFUNDTableAdapter;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart7;
        private System.Windows.Forms.BindingSource pREVIEWBindingSource;
        private DataSet1TableAdapters.P_REVIEWTableAdapter p_REVIEWTableAdapter;
    }
}