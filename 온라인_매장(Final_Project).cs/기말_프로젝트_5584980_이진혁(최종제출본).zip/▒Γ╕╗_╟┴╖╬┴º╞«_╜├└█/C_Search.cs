﻿using FakeItEasy;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 기말_프로젝트_시작
{
    public partial class C_Search : Form
    {
        DataTable productTable;
        DataTable cart;

        string USER;

        // 재고 검사
        string CNT = "0";
        string SELL = "0";

        public C_Search(string C_NAME)
        {
            InitializeComponent();
            this.USER = C_NAME;
        }

        private void C_Search_Load(object sender, EventArgs e)
        {
            // TODO: 이 코드는 데이터를 'dataSet1.C_DATE' 테이블에 로드합니다. 필요 시 이 코드를 이동하거나 제거할 수 있습니다.
            this.c_DATETableAdapter.Fill(this.dataSet1.C_DATE);
            // TODO: 이 코드는 데이터를 'dataSet1.C_PRICE_DESC' 테이블에 로드합니다. 필요 시 이 코드를 이동하거나 제거할 수 있습니다.
            this.c_PRICE_DESCTableAdapter.Fill(this.dataSet1.C_PRICE_DESC);
            // TODO: 이 코드는 데이터를 'dataSet1.C_PRICE_SCE' 테이블에 로드합니다. 필요 시 이 코드를 이동하거나 제거할 수 있습니다.
            this.c_PRICE_SCETableAdapter.Fill(this.dataSet1.C_PRICE_SCE);
            // TODO: 이 코드는 데이터를 'dataSet1.PRODUCT' 테이블에 로드합니다. 필요 시 이 코드를 이동하거나 제거할 수 있습니다.
            this.pRODUCTTableAdapter.Fill(this.dataSet1.PRODUCT);

            comboBox1.SelectedIndex = 0; // 초기값
            pRODUCTBindingSource1.Filter = "P_KIND LIKE '%" + comboBox1.Text + "%'";

            productTable = dataSet1.Tables["PRODUCT"];
            cart = dataSet1.Tables["CART"];
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e) // 종류 검색
        {
            pRODUCTBindingSource1.Filter = "P_KIND LIKE '%" + comboBox1.Text + "%'";
        }

        private void button5_Click(object sender, EventArgs e) // 장바구니 담기
        {
            // 1. 상품 종류
            if (textBox2.Text == "") // P_KIND
            {
                MessageBox.Show("상품 종류를 입력해주세요");
                return;
            }

            // 2. 상품 번호
            if (textBox3.Text == "") // P_NO
            {
                MessageBox.Show("상품 번호를 입력해주세요");
                return;
            }
            // 3. 상품 개수
            if(textBox1.Text == "") // P_COUNT
            {
                MessageBox.Show("상품 개수를 입력해주세요");
                return;
            }

            foreach (DataRow mydataRow in productTable.Rows) // P_PRICE 찾기
            {
                if (mydataRow["P_KIND"].ToString() == textBox2.Text && mydataRow["P_NO"].ToString() == textBox3.Text)
                {
                    CNT = mydataRow["P_COUNT"].ToString(); // 상품 남은 재고
                    SELL = mydataRow["P_SELL"].ToString(); // 상품 판매 개수

                    // 품절 여부 확인
                    if ((Convert.ToInt32(textBox1.Text) + Convert.ToInt32(SELL)) > Convert.ToInt32(CNT)) // 상품 판매 개수 + textBox1.Text == 14? // 2 + 4
                    {
                        int a = Convert.ToInt32(textBox1.Text) + Convert.ToInt32(SELL); // textBox1 = 2, SELL = 3
                        MessageBox.Show("해당 상품의 재고가 부족합니다. 재고를 확인해주세요");
                        textBox1.Text = "";
                        //textBox2.Text = "";
                        //textBox3.Text = "";
                        return;
                    }

                    try
                    {
                        cartTableAdapter1.Fill(dataSet1.CART); // 업데이트

                        // 임시 CART DB 추가
                        DataRow myNewDataRow = cart.NewRow();

                        var modifyNoRows = dataSet1.Tables["CART"].AsEnumerable();
                        int maxModifyNo = modifyNoRows.Any() ? modifyNoRows.Max(r => int.Parse(r["ORDER_NO"].ToString())) : 0;
                        string newModifyNo = (maxModifyNo + 1).ToString();

                        // 데이터값 입력
                        myNewDataRow["ORDER_NO"] = newModifyNo;
                        myNewDataRow["C_NO"] = USER;
                        myNewDataRow["P_KIND"] = textBox2.Text;
                        myNewDataRow["P_NO"] = textBox3.Text;
                        myNewDataRow["P_NAME"] = mydataRow["P_NAME"].ToString();
                        myNewDataRow["S_NO"] = mydataRow["C_NO"].ToString();
                        myNewDataRow["B_COUNT"] = textBox1.Text;
                        myNewDataRow["B_PRICE"] = mydataRow["P_PRICE"].ToString();
                        myNewDataRow["B_TOTAL_PRICE"] = Convert.ToInt32(textBox1.Text) * Convert.ToInt32(mydataRow["P_PRICE"].ToString());
                        myNewDataRow["CHOICE"] = 0;

                        dataSet1.Tables["CART"].Rows.Add(myNewDataRow); // Cart에 데이터 추가
                        // mydataRow["P_SELL"] = Convert.ToInt32(mydataRow["P_SELL"]) + 1; // 상품 판매 횟수 올리기 아직 안 샀으니 횟수 ㄴㄴ
                        pRODUCTTableAdapter.Update(this.dataSet1.PRODUCT); // PRODUCT 업데이트
                        try
                        {
                            cartTableAdapter1.Update(this.dataSet1.CART); // CART 업데이트
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("업데이트 중 오류가 발생했습니다: " + ex.Message);
                        }
                        MessageBox.Show("장바구니에 담았습니다!");

                        textBox1.Text = "";
                        textBox2.Text = "";
                        textBox3.Text = "";
                        break;
                    }
                    catch
                    {
                        MessageBox.Show("데이터 입력 실패");
                        textBox1.Text = "";
                        textBox2.Text = "";
                        textBox3.Text = "";
                        break;
                    }
                }
                else
                {
                }
            }
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
