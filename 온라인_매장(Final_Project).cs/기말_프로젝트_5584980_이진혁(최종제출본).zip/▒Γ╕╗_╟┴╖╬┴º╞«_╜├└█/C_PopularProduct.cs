﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 기말_프로젝트_시작
{
    public partial class C_PopularProduct : Form
    {
        public C_PopularProduct()
        {
            InitializeComponent();
        }

        private void C_PopularProduct_Load(object sender, EventArgs e)
        {
            // TODO: 이 코드는 데이터를 'dataSet1.P_TOP_10_SELL' 테이블에 로드합니다. 필요 시 이 코드를 이동하거나 제거할 수 있습니다.
            this.p_TOP_10_SELLTableAdapter.Fill(this.dataSet1.P_TOP_10_SELL);
            // TODO: 이 코드는 데이터를 'dataSet1.P_MODIFY' 테이블에 로드합니다. 필요 시 이 코드를 이동하거나 제거할 수 있습니다.
            this.p_MODIFYTableAdapter.Fill(this.dataSet1.P_MODIFY);

            this.chart1.ChartAreas["ChartArea1"].AxisX.Interval = 1;

        }
    }
}
